"""
字符级 Transformer 语言模型（decoder-only，因果自注意力，预测下一个字）

语料、字表、切块与 PPL 口径与课程 language_model.py 一致，可直接对比。

    python transformer_lm.py
    python transformer_lm.py --d_model 384 --layers 6 --seq_len 256 --epochs 25
    python transformer_lm.py --ckpt best_transformer.pt --generate "今天天气"
"""

import argparse
import glob
import math
import os
import random
import time

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader


def load_corpus(pattern):
    texts = []
    for path in glob.glob(pattern):
        with open(path, encoding="utf-8", errors="ignore") as f:
            texts.append(f.read())
    return "".join(texts)


def build_vocab(text, max_vocab=None):
    from collections import Counter
    counter = Counter(text)
    chars = [c for c, _ in counter.most_common(max_vocab)] if max_vocab else sorted(set(text))
    char2idx = {c: i for i, c in enumerate(chars)}
    idx2char = {i: c for c, i in char2idx.items()}
    return char2idx, idx2char


class CharDataset(Dataset):
    """x 为连续 seq_len 个字，y 为右移一位；stride 默认等于 seq_len（不重叠切块）。"""

    def __init__(self, text, char2idx, seq_len, stride=None):
        self.seq_len = seq_len
        self.stride = max(1, stride or seq_len)
        ids = [char2idx[c] for c in text if c in char2idx]
        self.data = torch.tensor(ids, dtype=torch.long)

    def __len__(self):
        return max(0, (len(self.data) - self.seq_len - 1) // self.stride + 1)

    def __getitem__(self, idx):
        start = idx * self.stride
        return (self.data[start: start + self.seq_len],
                self.data[start + 1: start + self.seq_len + 1])


class Block(nn.Module):
    """Pre-LN 结构：先归一化再进子层，残差走旁路。"""

    def __init__(self, d_model, nhead, dim_ff, dropout):
        super().__init__()
        self.ln1 = nn.LayerNorm(d_model)
        self.attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=True)
        self.ln2 = nn.LayerNorm(d_model)
        self.mlp = nn.Sequential(
            nn.Linear(d_model, dim_ff), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(dim_ff, d_model),
        )
        self.drop = nn.Dropout(dropout)

    def forward(self, x, mask):
        h = self.ln1(x)
        a, _ = self.attn(h, h, h, attn_mask=mask, need_weights=False)
        x = x + self.drop(a)
        return x + self.drop(self.mlp(self.ln2(x)))


class TransformerLM(nn.Module):
    def __init__(self, vocab_size, d_model=256, nhead=8, num_layers=4,
                 dim_ff=1024, max_len=256, dropout=0.1, tie_weights=True):
        super().__init__()
        self.max_len = max_len
        self.tok = nn.Embedding(vocab_size, d_model)
        self.pos = nn.Embedding(max_len, d_model)
        self.drop = nn.Dropout(dropout)
        self.blocks = nn.ModuleList(
            [Block(d_model, nhead, dim_ff, dropout) for _ in range(num_layers)]
        )
        self.ln_f = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab_size, bias=False)
        if tie_weights:      # 输入 embedding 与输出 softmax 共用同一张表
            self.head.weight = self.tok.weight
        self.apply(self._init_weights)

    @staticmethod
    def _init_weights(m):
        if isinstance(m, nn.Linear):
            nn.init.normal_(m.weight, std=0.02)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Embedding):
            nn.init.normal_(m.weight, std=0.02)

    def forward(self, x):
        B, T = x.shape
        pos = torch.arange(T, device=x.device)
        h = self.drop(self.tok(x) + self.pos(pos))
        # 上三角为 True：屏蔽右侧，保证每个位置只能看见左侧
        mask = torch.triu(torch.ones(T, T, dtype=torch.bool, device=x.device), diagonal=1)
        for blk in self.blocks:
            h = blk(h, mask)
        return self.head(self.ln_f(h))


def run_epoch(model, loader, criterion, optimizer, scheduler, scaler, device,
              use_amp, train=True, clip=1.0):
    model.train(train)
    total_loss, total_tokens = 0.0, 0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        if train:
            optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=use_amp):
            logits = model(x)
            loss = criterion(logits.reshape(-1, logits.size(-1)), y.reshape(-1))

        if train:
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            nn.utils.clip_grad_norm_(model.parameters(), clip)
            scaler.step(optimizer)
            scaler.update()
            if scheduler is not None:
                scheduler.step()

        total_loss += loss.item() * y.numel()
        total_tokens += y.numel()

    avg_loss = total_loss / max(1, total_tokens)
    return avg_loss, math.exp(avg_loss)


def warmup_cosine(optimizer, warmup_steps, total_steps, min_ratio=0.1):
    def lr_lambda(step):
        if step < warmup_steps:
            return step / max(1, warmup_steps)
        progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
        return min_ratio + (1 - min_ratio) * 0.5 * (1 + math.cos(math.pi * progress))
    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


@torch.no_grad()
def generate(model, char2idx, idx2char, prompt, max_new=80, topk=50,
             temperature=0.9, device=torch.device("cpu")):
    model.eval()
    ids = [char2idx[c] for c in prompt if c in char2idx] or [0]
    out = list(ids)
    for _ in range(max_new):
        x = torch.tensor([out[-model.max_len:]], dtype=torch.long, device=device)
        logits = model(x)[0, -1] / temperature
        v, idx = torch.topk(logits, topk)
        nxt = idx[torch.multinomial(torch.softmax(v, dim=-1), 1)].item()
        out.append(nxt)
    return "".join(idx2char.get(i, "") for i in out)


def build_model_from_args(args, vocab_size):
    return TransformerLM(
        vocab_size=vocab_size,
        d_model=args.d_model,
        nhead=args.nhead,
        num_layers=args.layers,
        dim_ff=args.dim_ff,
        max_len=args.max_len,
        dropout=args.dropout,
        tie_weights=not args.no_tie,
    )


def default_corpus(here):
    """依次尝试课件里几处常见位置，找不到就返回第一个，由用户用 --corpus 指定。"""
    candidates = [
        os.environ.get("CORPUS", ""),
        os.path.join(here, "..", "循环神经网络语言模型", "corpus_general.txt"),
        os.path.join(here, "..", "week4-语言模型", "week4-语言模型",
                     "循环神经网络语言模型", "corpus_general.txt"),
        os.path.join(here, "..", "..", "循环神经网络语言模型", "corpus_general.txt"),
    ]
    for path in candidates:
        if path and os.path.exists(path):
            return path
    return candidates[1]


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    parser = argparse.ArgumentParser()
    parser.add_argument("--corpus", default=default_corpus(here))
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--seq_len", type=int, default=128)
    parser.add_argument("--stride", type=int, default=0, help="0 表示等于 seq_len")
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--d_model", type=int, default=256)
    parser.add_argument("--nhead", type=int, default=8)
    parser.add_argument("--layers", type=int, default=4)
    parser.add_argument("--dim_ff", type=int, default=1024)
    parser.add_argument("--max_len", type=int, default=256)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--no_tie", action="store_true")
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--min_lr_ratio", type=float, default=0.1)
    parser.add_argument("--warmup_ratio", type=float, default=0.05)
    parser.add_argument("--weight_decay", type=float, default=0.01)
    parser.add_argument("--val_ratio", type=float, default=0.05)
    parser.add_argument("--max_vocab", type=int, default=4000, help="0 表示不限")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num_workers", type=int, default=0)
    parser.add_argument("--no_amp", action="store_true")
    parser.add_argument("--save", default=os.path.join(here, "best_transformer.pt"))
    parser.add_argument("--sample_every", type=int, default=1)
    parser.add_argument("--ckpt", default=None)
    parser.add_argument("--generate", default=None)
    parser.add_argument("--new_tokens", type=int, default=60)
    parser.add_argument("--topk", type=int, default=50)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    random.seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_amp = (device.type == "cuda") and not args.no_amp
    if device.type == "cuda":
        torch.backends.cuda.matmul.allow_tf32 = True

    if args.ckpt and args.generate is not None:
        ck = torch.load(args.ckpt, map_location=device, weights_only=False)
        ck_args = argparse.Namespace(**ck["args"])
        char2idx, idx2char = ck["char2idx"], ck["idx2char"]
        model = build_model_from_args(ck_args, len(char2idx)).to(device)
        model.load_state_dict(ck["model_state"])
        print(f"模型: {args.ckpt}  词表 {len(char2idx)}  设备 {device}")
        text = generate(model, char2idx, idx2char, args.generate,
                        args.new_tokens, args.topk, device=device)
        print(f"提示「{args.generate}」→ 续写:\n{text}")
        return

    assert args.seq_len <= args.max_len, "seq_len 不能超过 max_len"

    text = load_corpus(args.corpus)
    if not text:
        raise FileNotFoundError(f"未找到语料: {args.corpus}")
    print(f"设备: {device}  语料字符数: {len(text):,}")

    char2idx, idx2char = build_vocab(text, args.max_vocab or None)
    vocab_size = len(char2idx)
    print(f"词表大小: {vocab_size}")

    lines = text.splitlines()
    random.shuffle(lines)
    split = int(len(lines) * (1 - args.val_ratio))
    train_text, val_text = "\n".join(lines[:split]), "\n".join(lines[split:])

    train_ds = CharDataset(train_text, char2idx, args.seq_len, args.stride or args.seq_len)
    val_ds = CharDataset(val_text, char2idx, args.seq_len, args.stride or args.seq_len)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              drop_last=True, num_workers=args.num_workers)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False,
                            drop_last=False, num_workers=args.num_workers)
    print(f"训练样本 {len(train_ds):,} / 验证样本 {len(val_ds):,}")

    model = build_model_from_args(args, vocab_size).to(device)
    print(f"模型参数量: {sum(p.numel() for p in model.parameters()):,}  "
          f"(d_model={args.d_model}, layers={args.layers}, heads={args.nhead}, "
          f"ff={args.dim_ff}, tie={not args.no_tie})")

    decay, no_decay = [], []
    for name, p in model.named_parameters():
        (decay if p.ndim >= 2 else no_decay).append(p)
    optimizer = torch.optim.AdamW(
        [{"params": decay, "weight_decay": args.weight_decay},
         {"params": no_decay, "weight_decay": 0.0}],
        lr=args.lr, betas=(0.9, 0.95),
    )
    total_steps = max(1, len(train_loader)) * args.epochs
    scheduler = warmup_cosine(optimizer, int(total_steps * args.warmup_ratio),
                              total_steps, args.min_lr_ratio)
    criterion = nn.CrossEntropyLoss()
    try:
        scaler = torch.amp.GradScaler("cuda", enabled=use_amp)
    except (AttributeError, TypeError):
        scaler = torch.cuda.amp.GradScaler(enabled=use_amp)

    best_val_ppl = float("inf")
    print(f"\n{'Epoch':>6} {'Train Loss':>11} {'Train PPL':>10} {'Val Loss':>10} "
          f"{'Val PPL':>9} {'LR':>9} {'秒':>6}")
    print("-" * 68)

    for epoch in range(1, args.epochs + 1):
        t0 = time.time()
        tr_loss, tr_ppl = run_epoch(model, train_loader, criterion, optimizer,
                                    scheduler, scaler, device, use_amp, train=True)
        va_loss, va_ppl = run_epoch(model, val_loader, criterion, None,
                                    None, scaler, device, use_amp, train=False)

        marker = ""
        if va_ppl < best_val_ppl:
            best_val_ppl = va_ppl
            torch.save({
                "model_state": model.state_dict(),
                "char2idx": char2idx,
                "idx2char": idx2char,
                "args": vars(args),
            }, args.save)
            marker = "  *"
        print(f"{epoch:>6} {tr_loss:>11.4f} {tr_ppl:>10.2f} {va_loss:>10.4f} "
              f"{va_ppl:>9.2f} {optimizer.param_groups[0]['lr']:>9.2e} "
              f"{time.time() - t0:>6.1f}{marker}")

        if epoch % max(1, args.sample_every) == 0:
            print("        样例: " + generate(model, char2idx, idx2char, "今天天气",
                                           max_new=40, topk=50, device=device))

    print(f"\n训练完成。最佳验证 PPL: {best_val_ppl:.2f}  已保存至 {args.save}")


if __name__ == "__main__":
    main()
