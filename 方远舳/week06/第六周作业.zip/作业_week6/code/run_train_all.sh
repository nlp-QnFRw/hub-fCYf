#!/usr/bin/env bash
# 串行跑完 8 个「数据集 × 预训练模型」组合（GPU 只有一个，并发会 OOM）
set -u
PY=/e/PyTorch/conda_envs/py312/python.exe
cd "$(dirname "$0")"
for ds in tnews thucnews; do
  for bb in bert-base-chinese chinese-roberta-wwm-ext chinese-macbert-base chinese-rbt3; do
    tag="${ds}_${bb}"
    echo "=== [$(date +%H:%M:%S)] start $tag" >> outputs/logs/run_all.log
    $PY exp_a_models/train_backbone.py --backbone "$bb" --dataset "$ds" --epochs 3 \
        > "outputs/logs/train_${tag}.log" 2>&1
    echo "=== [$(date +%H:%M:%S)] done  $tag (exit $?)" >> outputs/logs/run_all.log
  done
done
echo "ALL TRAIN DONE $(date)" >> outputs/logs/run_all.log
