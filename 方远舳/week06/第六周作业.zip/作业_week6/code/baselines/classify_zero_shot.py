"""
方法四：大模型零样本（L3，不训练）—— 通用版

课件在 TNEWS 上给零样本判了「不可用」（Macro-F1 0.105，且 15 类只输出 8 类）。
这个判断有两个可能的解释，必须分开：
  ① 生成式模型天生不适合做「封闭标签分类」；
  ② 只是 TNEWS 的类别名（故事/文化/证券/电竞）太抽象，模型抓不住语义边界。
换到 THUCNews（体育/娱乐/财经/科技/房产…全是**高频常识词**）就能把两者区分开：
  如果分数明显上去 → 塌缩是「标签词的可理解性」问题，不是模型能力问题；
  如果还是塌到一两类 → 那就是方法本身在封闭标签上不行。
这就是「换数据集」对结论的价值——它把一个含糊的判断拆成了可验证的因果。

Qwen3 必须 `enable_thinking=False`：不传会先吐 `<think>` 推理链，
把「只输出类别名」的格式彻底打乱（课件踩过的坑，这里照抄）。
"""

import argparse
import json
import sys
import time
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from common.datasets import label_names, load_clean, num_labels
from common.metrics import classification_report, pred_distribution
from common.model_paths import PROJECT_ROOT

CODE_ROOT = Path(__file__).resolve().parent.parent

TEMPLATE = (
    "你是一个新闻标题分类助手。请将给定的新闻标题分类到以下类别之一，"
    "只输出类别名称，不要输出任何其他内容。\n可选类别：{labels}"
)


def parse_label(text: str, labels) -> int:
    """包含匹配 + 最长优先：容忍「类别：财经。」这类噪声；抽不到返回 -1（记为失败）"""
    text = text.strip()
    hits = [n for n in labels if n in text]
    if not hits:
        return -1
    return labels.index(max(hits, key=len))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="tnews", choices=["tnews", "thucnews"])
    ap.add_argument("--n", type=int, default=500)
    ap.add_argument("--model", default="Qwen3-0.6B")
    ap.add_argument("--max_new_tokens", type=int, default=8)
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer

    device = "cuda" if torch.cuda.is_available() else "cpu"
    # Qwen3 不在 backbone 表里（它是生成式模型，不参与微调对比），直接按目录名找
    mdir = Path(args.model)
    if not mdir.is_absolute():
        mdir = PROJECT_ROOT / "pretrain_models" / args.model
    assert (mdir / "config.json").exists(), f"未找到模型目录 {mdir}"
    tok = AutoTokenizer.from_pretrained(str(mdir))
    # 注意：transformers 4.55 的 from_pretrained 还不认 `dtype=`（4.56+ 才改名），
    # 传 dtype 会报 `unexpected keyword argument`，这里用旧名 torch_dtype。
    model = AutoModelForCausalLM.from_pretrained(
        str(mdir), torch_dtype=torch.float16 if device == "cuda" else torch.float32
    ).to(device).eval()

    labels = label_names(args.dataset)
    system = TEMPLATE.format(labels="、".join(labels))
    samples, meta = load_clean(args.dataset, n=args.n or None)

    preds, raws, t0 = [], [], time.time()
    for i, d in enumerate(samples):
        msgs = [{"role": "system", "content": system},
                {"role": "user", "content": d["sentence"]}]
        text = tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True,
                                       enable_thinking=False)
        enc = tok(text, return_tensors="pt").to(device)
        with torch.no_grad():
            out = model.generate(**enc, max_new_tokens=args.max_new_tokens, do_sample=False,
                                 pad_token_id=tok.eos_token_id)
        raw = tok.decode(out[0][enc["input_ids"].shape[1]:], skip_special_tokens=True)
        raws.append(raw)
        preds.append(parse_label(raw, labels))
        if i % 50 == 0:
            print(f"  {i}/{len(samples)} {time.time() - t0:.0f}s", flush=True)

    report = classification_report([d["label"] for d in samples], preds,
                                   num_classes=num_labels(args.dataset))
    report.update({
        "method": "qwen3_zero_shot", "dataset": args.dataset,
        "model": args.model,
        "sec_per_item": round((time.time() - t0) / len(samples), 2),
        "pred_distribution": pred_distribution(preds, num_labels(args.dataset)),
        "random_baseline_acc": round(1 / len(labels), 4),
    })

    out = CODE_ROOT / (args.out or f"outputs/pred_{args.dataset}_zeroshot.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"meta": meta, "report": report,
                               "preds": [{"text": d["sentence"], "true": d["label"],
                                          "pred": p, "raw": r}
                                         for d, p, r in zip(samples, preds, raws)]},
                              ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"[{args.dataset}] zero-shot acc={report['acc_incl_unparsed']} "
          f"f1={report['macro_f1']} 覆盖 {report['pred_distribution']['used_classes']}/{len(labels)} 类 "
          f"{report['sec_per_item']}s/条")
    print(f"→ {out}")


if __name__ == "__main__":
    main()
