"""
方法一：规则 / 关键词（L0 基线）—— 通用版，两套数据集共用

为什么「换数据集」时要重跑规则法，而不是直接引用课件那个 0.126：
  规则法的分数**完全由「类别名是否字面出现在文本里」决定**，不是模型能力。
  TNEWS 的标题是口语化提问（"上课时学生手机响个不停…"），几乎不写"教育"两个字；
  THUCNews 的标题是门户站点标题（"…国奥队…"），也不写"体育"。
  两个数据集上规则法都会很低，但这个「低」是两种不同的低，
  不重跑就分不清是「规则天生不行」还是「这份数据的写法特殊」。

策略（故意保持最笨）：
  按类别表顺序，第一个出现在文本里的类别名即为预测；都没命中 → -1（记为失败）。
  不做同义词、不做优先级、不做正则——规则法就是要暴露它的天花板，
  加人工调参就变成「人在标注」，掩盖了 L0 的真实水平。
"""

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from common.datasets import label_names, load_clean, load_splits, num_labels
from common.metrics import classification_report, pred_distribution

CODE_ROOT = Path(__file__).resolve().parent.parent


def classify(text: str, labels, fallback: int) -> int:
    """
    未命中时回落到 fallback（训练集众数类），而不是返回 -1。

    为什么不能返回 -1：课件 metrics 的 macro_f1 只在「有预测」的样本上算，
    命中率只有 6% 时，剩下 94% 全被剔除，F1 会跳到 0.27 这种假高分。
    回落到众数类 = 把「猜一个大类」这个最差策略也算进去，才是 L0 的真实下限。
    """
    for i, name in enumerate(labels):
        if name in text:
            return i
    return fallback


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="tnews", choices=["tnews", "thucnews"])
    ap.add_argument("--n", type=int, default=500)
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    labels = label_names(args.dataset)
    train_data, _ = load_splits(args.dataset)
    samples, meta = load_clean(args.dataset, n=args.n or None)

    from collections import Counter
    fallback = Counter(d["label"] for d in train_data).most_common(1)[0][0]

    preds = [classify(d["sentence"], labels, fallback) for d in samples]
    y_true = [d["label"] for d in samples]
    report = classification_report(y_true, preds, num_classes=num_labels(args.dataset))
    hit = sum(1 for d, p in zip(samples, preds) if labels[p] in d["sentence"])
    report.update({
        "method": "rule_keyword",
        "dataset": args.dataset,
        "hit_rate": round(hit / len(preds), 4),
        "fallback_class": labels[fallback],
        "pred_distribution": pred_distribution(preds, num_labels(args.dataset)),
        "random_baseline_acc": round(1 / len(labels), 4),
    })

    out = CODE_ROOT / (args.out or f"outputs/pred_{args.dataset}_rule.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"meta": meta, "report": report,
                               "preds": [{"text": d["sentence"], "true": d["label"], "pred": p}
                                         for d, p in zip(samples, preds)]},
                              ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"[{args.dataset}] 规则法：命中率 {report['hit_rate']:.2%} "
          f"acc={report['acc_incl_unparsed']} f1={report['macro_f1']} "
          f"（随机基线 {report['random_baseline_acc']}）")
    print(f"→ {out}")


if __name__ == "__main__":
    main()
