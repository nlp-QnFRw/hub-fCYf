"""
方法二：TF-IDF + LinearSVC（L1 基线）—— 通用版

课件在这个位置留了一个「反直觉」的结论：
  TNEWS 上把训练集砍到 15%，BERT 与 TF-IDF 的差距从 2.6 个点拉到 5.7 个点，
  也就是「TF-IDF 的主场是小样本 / 数据封闭」，而不是「TF-IDF 过时了」。
本脚本用 --train_frac 把这个实验做成可复现的一行命令，并在两套数据上各跑一遍，
验证这条结论是任务特性还是数据集特性。

为什么中文短文本用字 n-gram 而不是分词：
  不用装 jieba、不用维护词典，`char_wb(1,2)` 就能抓住「股/楼/球/手机」这类信号；
  而且是「无损」的——不依赖分词器版本，换个数据集结论还能复现。
"""

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from common.datasets import label_names, load_clean, load_splits, num_labels
from common.metrics import classification_report, pred_distribution

CODE_ROOT = Path(__file__).resolve().parent.parent


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="tnews", choices=["tnews", "thucnews"])
    ap.add_argument("--n", type=int, default=500, help="评测条数")
    ap.add_argument("--ngram", default="1,2", help="字符 n-gram 范围")
    ap.add_argument("--C", type=float, default=1.0, help="LinearSVC 正则强度")
    ap.add_argument("--train_frac", type=float, default=1.0,
                    help="训练集使用比例（做数据量实验：0.15 / 0.5 / 1.0）")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.svm import LinearSVC

    train, _ = load_splits(args.dataset)
    if args.train_frac < 1.0:
        rng = np.random.RandomState(args.seed)
        idx = rng.permutation(len(train))[: int(len(train) * args.train_frac)]
        train = [train[i] for i in idx]

    samples, meta = load_clean(args.dataset, n=args.n or None)
    lo, hi = (int(x) for x in args.ngram.split(","))

    # 与课件完全同参：analyzer="char"、不加 sublinear_tf。
    # 这两项都影响分数（char_wb + sublinear 在 TNEWS 上能把 F1 抬高约 2 个点），
    # 一旦自己改了就再也对不上课件的 0.472，后面的对比也就没法归因。
    vec = TfidfVectorizer(analyzer="char", ngram_range=(lo, hi), max_features=300000)
    t0 = time.time()
    Xtr = vec.fit_transform([d["sentence"] for d in train])
    Xte = vec.transform([d["sentence"] for d in samples])
    clf = LinearSVC(C=args.C).fit(Xtr, [d["label"] for d in train])
    preds = clf.predict(Xte).tolist()
    fit_seconds = round(time.time() - t0, 1)

    report = classification_report([d["label"] for d in samples], preds,
                                   num_classes=num_labels(args.dataset))
    report.update({
        "method": "tfidf_svm", "dataset": args.dataset,
        "n_train_used": len(train), "train_frac": args.train_frac,
        "fit_seconds": fit_seconds, "ngram": args.ngram, "C": args.C,
        "n_features": int(Xtr.shape[1]),
        "pred_distribution": pred_distribution(preds, num_labels(args.dataset)),
    })

    suffix = "" if args.train_frac >= 1.0 else f"_frac{args.train_frac}"
    out = CODE_ROOT / (args.out or f"outputs/pred_{args.dataset}_tfidf{suffix}.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"meta": meta, "report": report,
                               "preds": [{"text": d["sentence"], "true": d["label"], "pred": p}
                                         for d, p in zip(samples, preds)]},
                              ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"[{args.dataset}] TF-IDF+SVM train={len(train)} "
          f"acc={report['acc']} f1={report['macro_f1']} features={Xtr.shape[1]} "
          f"{fit_seconds}s")
    print(f"→ {out}")


if __name__ == "__main__":
    main()
