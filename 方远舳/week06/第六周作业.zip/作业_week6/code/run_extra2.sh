#!/usr/bin/env bash
# 主训练收尾后的第二批：① 补跑 thucnews/bert-base（旧结果是 100 条冒烟残留，被 skip 逻辑误跳）② zero-shot ③ 数据量实验
set -u
PY=/e/PyTorch/conda_envs/py312/python.exe
cd "$(dirname "$0")"

echo "=== [$(date +%H:%M:%S)] start thucnews_bert-base-chinese (redo, 冒烟残留)" >> outputs/logs/run_all.log
$PY exp_a_models/train_backbone.py --backbone bert-base-chinese --dataset thucnews --epochs 3 \
    > outputs/logs/train_thucnews_bert-base-chinese.log 2>&1
echo "=== [$(date +%H:%M:%S)] done  thucnews_bert-base-chinese" >> outputs/logs/run_all.log

for ds in tnews thucnews; do
  echo "=== [$(date +%H:%M:%S)] zero-shot $ds" >> outputs/logs/run_all.log
  $PY baselines/classify_zero_shot.py --dataset "$ds" --n 500 > "outputs/logs/zeroshot_${ds}.log" 2>&1
  echo "=== [$(date +%H:%M:%S)] done zero-shot $ds" >> outputs/logs/run_all.log
  echo "=== [$(date +%H:%M:%S)] bert frac0.15 $ds" >> outputs/logs/run_all.log
  $PY exp_a_models/train_backbone.py --backbone bert-base-chinese --dataset "$ds" --epochs 3 \
      --train_frac 0.15 > "outputs/logs/train_${ds}_bert-base-chinese_frac0.15.log" 2>&1
  echo "=== [$(date +%H:%M:%S)] done bert frac0.15 $ds" >> outputs/logs/run_all.log
done
echo "EXTRA DONE $(date)" >> outputs/logs/run_all.log
