#!/usr/bin/env bash
# 续跑：macbert 在 20:08 被外部中断（父进程被杀），从它接着往下跑
set -u
PY=/e/PyTorch/conda_envs/py312/python.exe
cd "$(dirname "$0")"
run() {  # run <tag> <args...>
  local tag=$1; shift
  if [ -s "outputs/pred_${tag}.json" ]; then echo "=== [$(date +%H:%M:%S)] skip $tag (已有结果)" >> outputs/logs/run_all.log; return; fi
  echo "=== [$(date +%H:%M:%S)] start $tag" >> outputs/logs/run_all.log
  $PY exp_a_models/train_backbone.py "$@" > "outputs/logs/train_${tag}.log" 2>&1
  echo "=== [$(date +%H:%M:%S)] done  $tag (exit $?)" >> outputs/logs/run_all.log
}
for ds in tnews thucnews; do
  for bb in chinese-macbert-base chinese-rbt3; do
    run "${ds}_${bb}" --backbone "$bb" --dataset "$ds" --epochs 3
  done
done
for bb in bert-base-chinese chinese-roberta-wwm-ext; do
  run "thucnews_${bb}" --backbone "$bb" --dataset thucnews --epochs 3
done
echo "REST TRAIN DONE $(date)" >> outputs/logs/run_all.log
