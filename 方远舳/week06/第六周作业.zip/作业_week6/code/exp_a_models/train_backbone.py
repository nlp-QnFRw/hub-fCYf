"""
实验 A 引擎：任意预训练模型 × 任意数据集，同一套训练/评测口径

为什么只写一个脚本、用参数切换 backbone 和数据集：
  对比实验的**唯一变量**必须只有一个。如果「换模型」要改代码、改学习率、改 batch，
  那最后涨的 0.5 个点到底来自模型还是来自调参，谁也说不清。
  所以这里把除了 `--backbone` / `--dataset` 以外的一切都钉死：
  同一批数据、同一份超参、同一个评测集、同一个 seed。

超参照搬课件（不重新调）：
  lr 2e-5（BERT 层）/ 头 ×5（分层学习率，头是随机初始化的要学得快）
  3 epoch、batch 64、max_length 64、warmup 10%、AdamW + weight_decay 0.01、AMP fp16
  类别加权（balanced）默认开——TNEWS 有 23× 不均衡，THUCNews 基本均衡，
  都开是为了「同一份超参」这个原则，而不是为了给哪个数据集偷偷调优。

用法：
  python exp_a_models/train_backbone.py --backbone bert-base-chinese --dataset tnews
  python exp_a_models/train_backbone.py --backbone chinese-rbt3 --dataset thucnews --epochs 3
  python exp_a_models/train_backbone.py --backbone chinese-macbert-base --dataset tnews \
      --max_steps 3 --max_eval 200          # 冒烟：只验流程，30 秒
"""

import argparse
import json
import sys
import time
from pathlib import Path

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from common.datasets import label_names, load_clean, load_splits, num_labels
from common.metrics import classification_report, expected_calibration_error
from common.model_paths import BACKBONES, resolve_model, model_size

CODE_ROOT = Path(__file__).resolve().parent.parent
OUT_DIR = CODE_ROOT / "outputs"


class TextDataset(Dataset):
    """{"sentence","label"} → BERT 输入张量（两个数据集共用，字段名一致是前提）"""

    def __init__(self, data, tok, max_length=64):
        self.data, self.tok, self.max_length = data, tok, max_length

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        d = self.data[i]
        enc = self.tok(d["sentence"], truncation=True, max_length=self.max_length,
                       padding="max_length", return_tensors="pt")
        return {"input_ids": enc["input_ids"][0],
                "attention_mask": enc["attention_mask"][0],
                "labels": torch.tensor(d["label"])}


class BackboneClassifier(nn.Module):
    """
    结构照搬课件：预训练本体 + [CLS] 池化 + 线性头（只加一层，不加 CNN/RNN）。
    这样「换模型」真的是换预训练本体，头部的表达能力四个模型完全一致。
    """

    def __init__(self, model_dir, num_classes, pool="cls", dropout=0.1):
        super().__init__()
        from transformers import AutoModel
        self.encoder = AutoModel.from_pretrained(str(model_dir))
        self.pool = pool
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(self.encoder.config.hidden_size, num_classes)

    def forward(self, input_ids, attention_mask):
        out = self.encoder(input_ids=input_ids, attention_mask=attention_mask, return_dict=True)
        hs = out.last_hidden_state
        if self.pool == "cls":
            vec = hs[:, 0]
        else:
            m = attention_mask.unsqueeze(-1).float()
            if self.pool == "mean":
                vec = (hs * m).sum(1) / m.sum(1).clamp(min=1e-9)
            else:
                vec = hs.masked_fill(m == 0, -1e9).max(1).values
        return self.classifier(self.dropout(vec))


@torch.no_grad()
def evaluate(model, loader, device, n_classes):
    import numpy as np
    from sklearn.metrics import accuracy_score, f1_score
    model.eval()
    ys, ps, probs = [], [], []
    for batch in loader:
        logits = model(batch["input_ids"].to(device), batch["attention_mask"].to(device))
        probs.append(torch.softmax(logits.float(), dim=-1).cpu())
        ps.extend(logits.argmax(-1).cpu().tolist())
        ys.extend(batch["labels"].tolist())
    probs = torch.cat(probs).numpy()
    return {
        "acc": round(float(accuracy_score(ys, ps)), 4),
        "macro_f1": round(float(f1_score(ys, ps, average="macro")), 4),
        "ece": expected_calibration_error(np.asarray(ys), probs),
        "per_class_recall": classification_report(ys, ps, num_classes=n_classes)["per_class_recall"],
        "confusion_matrix": classification_report(ys, ps, num_classes=n_classes)["confusion_matrix"],
        "_ys": ys, "_ps": ps,
    }


def count_params(model):
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return total, trainable


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--backbone", default="bert-base-chinese", choices=list(BACKBONES))
    ap.add_argument("--dataset", default="tnews", choices=["tnews", "thucnews"])
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--batch_size", type=int, default=64)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--head_lr_mult", type=float, default=5.0)
    ap.add_argument("--max_length", type=int, default=64)
    ap.add_argument("--pool", default="cls", choices=["cls", "mean", "max"])
    ap.add_argument("--no_class_weight", action="store_true")
    ap.add_argument("--n_eval", type=int, default=500, help="评测抽样条数（0=全量干净集）")
    ap.add_argument("--max_steps", type=int, default=0, help="冒烟：每 epoch 最多几步")
    ap.add_argument("--no_save", action="store_true", help="冒烟：不落盘 ckpt")
    ap.add_argument("--train_frac", type=float, default=1.0,
                    help="训练集使用比例（数据量实验：0.15 / 0.5 / 1.0）")
    ap.add_argument("--seed", type=int, default=42, help="数据子集抽样种子")
    ap.add_argument("--tag", default="", help="结果文件名后缀，默认 <dataset>_<backbone>")
    args = ap.parse_args()

    from transformers import AutoTokenizer

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model_dir = resolve_model(args.backbone)
    tag = args.tag or f"{args.dataset}_{args.backbone}"
    if args.train_frac < 1.0:
        tag += f"_frac{args.train_frac}"

    tok = AutoTokenizer.from_pretrained(str(model_dir))
    train, _ = load_splits(args.dataset)
    if args.train_frac < 1.0:
        # 数据量实验：固定 seed 抽一部分训练集，**评测集完全不动**——
        # 只有训练量变化，曲线上的点才是可比的
        import numpy as np
        keep = np.random.RandomState(args.seed).permutation(len(train))[: int(len(train) * args.train_frac)]
        train = [train[i] for i in keep]
    samples, meta = load_clean(args.dataset, n=args.n_eval or None)
    labels = label_names(args.dataset)
    n_classes = num_labels(args.dataset)

    print(f"[cfg] backbone={args.backbone} ({BACKBONES[args.backbone][1]}, "
          f"{BACKBONES[args.backbone][3]}, 权重 {model_size(model_dir)})", flush=True)
    print(f"[cfg] dataset={args.dataset} train={len(train)} eval={len(samples)} "
          f"classes={n_classes} dup_removed={meta['n_dup']}", flush=True)

    train_dl = DataLoader(TextDataset(train, tok, args.max_length),
                          batch_size=args.batch_size, shuffle=True, num_workers=0)
    val_dl = DataLoader(TextDataset(samples, tok, args.max_length),
                        batch_size=args.batch_size, num_workers=0)

    model = BackboneClassifier(model_dir, n_classes, pool=args.pool).to(device)
    total_p, train_p = count_params(model)

    head = list(model.classifier.parameters()) + list(model.dropout.parameters())
    body = [p for n, p in model.named_parameters()
            if not (n.startswith("classifier") or n.startswith("dropout"))]
    opt = torch.optim.AdamW([
        {"params": body, "lr": args.lr},
        {"params": head, "lr": args.lr * args.head_lr_mult},
    ], weight_decay=0.01)

    if args.no_class_weight:
        weight = None
    else:
        import numpy as np
        from sklearn.utils.class_weight import compute_class_weight
        cw = compute_class_weight("balanced", classes=np.arange(n_classes),
                                  y=[d["label"] for d in train])
        weight = torch.tensor(cw, dtype=torch.float).to(device)
    crit = nn.CrossEntropyLoss(weight=weight)

    steps_per_epoch = min(len(train_dl), args.max_steps) if args.max_steps else len(train_dl)
    total_steps = steps_per_epoch * args.epochs
    warmup = int(total_steps * 0.1)
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: s / max(1, warmup) if s < warmup
        else max(0.0, (total_steps - s) / max(1, total_steps - warmup)))
    scaler = torch.amp.GradScaler("cuda", enabled=(device == "cuda"))

    # AMP 的第一步如果梯度含 inf/NaN，scaler 会跳过 optimizer.step()，
    # 于是第一轮 lr_scheduler 先于 optimizer.step 被调用，PyTorch 会警告。
    # 这里只屏蔽这条已知无害的告警，不改训练逻辑（其余告警保留，别把真问题一起吃掉）。
    import warnings
    warnings.filterwarnings("ignore", message="Detected call of `lr_scheduler.step()`")

    if device == "cuda":
        torch.cuda.reset_peak_memory_stats()

    t_start = time.time()
    log, best = [], 0.0
    for epoch in range(1, args.epochs + 1):
        model.train()
        t0, running, n_step = time.time(), 0.0, 0
        for i, batch in enumerate(train_dl):
            ids = batch["input_ids"].to(device)
            mask = batch["attention_mask"].to(device)
            y = batch["labels"].to(device)
            opt.zero_grad(set_to_none=True)
            with torch.autocast("cuda", dtype=torch.float16, enabled=(device == "cuda")):
                loss = crit(model(ids, mask), y)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            sched.step()
            running += loss.item()
            n_step += 1
            if i % 200 == 0:
                print(f"  epoch {epoch} step {i}/{steps_per_epoch} loss={loss.item():.4f}", flush=True)
            if args.max_steps and n_step >= args.max_steps:
                break

        res = evaluate(model, val_dl, device, n_classes)
        log.append({"epoch": epoch, "train_loss": round(running / max(1, n_step), 4),
                    "val_acc": res["acc"], "val_macro_f1": res["macro_f1"],
                    "val_ece": res["ece"], "epoch_seconds": round(time.time() - t0, 1)})
        print(f"epoch {epoch}: val_acc={res['acc']} val_f1={res['macro_f1']} ece={res['ece']} "
              f"({time.time() - t0:.0f}s)", flush=True)

        if res["macro_f1"] > best:
            best = res["macro_f1"]
            if not args.no_save:
                OUT_DIR.mkdir(parents=True, exist_ok=True)
                torch.save({"state_dict": model.state_dict(), "pool": args.pool,
                            "backbone": args.backbone, "dataset": args.dataset,
                            "labels": labels, "max_length": args.max_length,
                            "val_acc": res["acc"], "val_macro_f1": res["macro_f1"],
                            "args": vars(args)}, OUT_DIR / f"ckpt_{tag}.pt")

    train_seconds = round(time.time() - t_start, 1)
    peak_mem = round(torch.cuda.max_memory_allocated() / 1024 ** 3, 2) if device == "cuda" else 0.0

    # 用「最后一轮」的模型出最终评测；ctk 里存的是最好一轮，两者的差写进 result 便于核对
    final = evaluate(model, val_dl, device, n_classes)
    report = classification_report([d["label"] for d in samples], final["_ps"], num_classes=n_classes)
    report.update({
        "acc": final["acc"], "macro_f1": final["macro_f1"], "ece": final["ece"],
        "method": f"finetune:{args.backbone}",
        "dataset": args.dataset, "backbone": args.backbone,
        "params_total": total_p, "params_trainable": train_p,
        "train_seconds": train_seconds, "peak_gpu_gb": peak_mem,
        "best_epoch_macro_f1": best,
        "hyper": {k: v for k, v in vars(args).items()},
    })

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    payload = {"meta": meta, "report": report, "epoch_log": log,
               "preds": [{"text": d["sentence"], "true": d["label"], "pred": p}
                         for d, p in zip(samples, final["_ps"])]}
    (OUT_DIR / f"pred_{tag}.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"[done] {args.backbone} @ {args.dataset}: acc={final['acc']} "
          f"macro_f1={final['macro_f1']} 耗时 {train_seconds}s 峰值显存 {peak_mem}GB")
    print(f"→ {OUT_DIR / ('pred_' + tag + '.json')}")


if __name__ == "__main__":
    main()
