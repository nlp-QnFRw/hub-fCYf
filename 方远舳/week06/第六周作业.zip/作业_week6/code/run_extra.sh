#!/usr/bin/env bash
# 主实验（8 个 数据集×模型）跑完之后再跑这一批：
#   ① LLM 零样本（Qwen3-0.6B，两套数据集各一次）
#   ② 数据量实验：BERT 只用 15% 训练数据（与 TF-IDF 的 frac 点对齐）
set -u
PY=/e/PyTorch/conda_envs/py312/python.exe
cd "$(dirname "$0")"

for ds in tnews thucnews; do
  echo "=== [$(date +%H:%M:%S)] zero-shot $ds" >> outputs/logs/run_all.log
  $PY baselines/classify_zero_shot.py --dataset "$ds" --n 500 \
      > "outputs/logs/zeroshot_${ds}.log" 2>&1
  echo "=== [$(date +%H:%M:%S)] done zero-shot $ds" >> outputs/logs/run_all.log
done

for ds in tnews thucnews; do
  echo "=== [$(date +%H:%M:%S)] bert-base frac0.15 $ds" >> outputs/logs/run_all.log
  $PY exp_a_models/train_backbone.py --backbone bert-base-chinese --dataset "$ds" \
      --epochs 3 --train_frac 0.15 > "outputs/logs/train_${ds}_bert-base-chinese_frac0.15.log" 2>&1
  echo "=== [$(date +%H:%M:%S)] done bert frac0.15 $ds" >> outputs/logs/run_all.log
done
echo "ALL EXTRA DONE $(date)" >> outputs/logs/run_all.log
