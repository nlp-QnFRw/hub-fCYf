"""
预训练模型注册表与本地定位（离线可跑）

作业要做「换预训练模型」的对比，所以模型名必须是**参数**，不能写死在代码里。
这里维护一张表：模型名 → 目录名 + 一句话说明 + 大致规模，
训练脚本只认名字，换模型 = 换一个 `--backbone` 参数。

四个 backbone 的选法（不是随手挑的）：
  bert-base-chinese           12 层 / 102M，课件基线。中文 BERT 的「原版」，字级 MLM。
  chinese-roberta-wwm-ext     12 层 / 102M，RoBERTa 预训练配方 + 全词掩码（wwm）。
                              同参数量、只换预训练方式 → 能单独回答「预训练质量值多少」。
  chinese-macbert-base        12 层 / 102M，MacBERT：用相似词替换做 MLM 纠偏。
                              同参数量、第三种预训练目标 → 三者的差就是「预训练目标」的价。
  chinese-rbt3                3 层 / 16M，层数砍到 1/4 → 回答「容量能压到多小还够用」。
                              它跑得快，是「边缘部署 / 秒级重训」场景的参照点。

为什么不用更大的模型（比如 24 层的 large）：
  显存 8 GB，large + batch 64 + 64 长度会 OOM；而且作业要比的是「同预算下的选择」，
  不是「谁钱多谁赢」。这一点在说明里要写清楚，否则「为什么不用 large」是必被问的。

用法：
  from common.model_paths import resolve_model, BACKBONES
  path = resolve_model("chinese-macbert-base")
"""

import os
from pathlib import Path

CODE_ROOT = Path(__file__).resolve().parent.parent
PROJECT_ROOT = CODE_ROOT.parent          # 作业根目录（含 pretrain_models/）

# 模型名 → (目录名, 说明, 层数, 参数量(约), 预训练目标)
BACKBONES = {
    "bert-base-chinese": ("bert-base-chinese", "课件基线：中文 BERT，字级 MLM", 12, "102M", "MLM(字)"),
    "chinese-roberta-wwm-ext": ("chinese-roberta-wwm-ext", "RoBERTa 配方 + 全词掩码", 12, "102M", "MLM(全词)"),
    "chinese-macbert-base": ("chinese-macbert-base", "MacBERT：相似词替换纠偏", 12, "102M", "Mac-MLM"),
    "chinese-rbt3": ("chinese-rbt3", "3 层小模型（1/4 深度）", 3, "16M", "MLM(字)"),
}

EXTRA_ROOTS = [
    PROJECT_ROOT / "pretrain_models",
    Path(r"E:\大模型课程\4\bert-base-chinese"),   # 课件第 4 周的本地 BERT（可直接引用）
]


def _has_weights(p: Path) -> bool:
    """目录里必须真的有权重——否则会拿到半下载的空目录（离线课堂最常见的坑）"""
    if not p.is_dir():
        return False
    return any(p.glob("*.safetensors")) or (p / "pytorch_model.bin").exists()


def resolve_model(name: str) -> Path:
    if name not in BACKBONES:
        raise KeyError(f"未知 backbone：{name}，可选 {list(BACKBONES)}")
    dir_name = BACKBONES[name][0]
    roots = [Path(os.environ["W6_MODELS"])] if os.environ.get("W6_MODELS") else []
    roots += EXTRA_ROOTS

    tried = []
    for root in roots:
        # 两种摆法都接受：root 本身就是模型目录，或 root/<dir_name> 是模型目录
        for c in (root, root / dir_name):
            tried.append(c)
            if c.name == dir_name and _has_weights(c):
                return c
    raise FileNotFoundError(
        "未找到本地模型 %s，尝试过：\n  %s\n"
        "可从 hf-mirror 下载到 pretrain_models/%s/ 后重试。"
        % (name, "\n  ".join(str(t) for t in tried), dir_name)
    )


def model_size(path: Path) -> str:
    """权重大小（MB），用来解释「同参数量的两个模型为什么速度不一样」"""
    total = sum(f.stat().st_size for f in path.glob("*") if f.suffix in (".bin", ".safetensors"))
    return f"{total / 1024 / 1024:.0f}MB"


if __name__ == "__main__":
    for name in BACKBONES:
        try:
            p = resolve_model(name)
            print(f"{name:<26} -> {p}  ({model_size(p)})")
        except FileNotFoundError as e:
            print(f"{name:<26} -> [缺失] {e}")
