"""
双数据集注册表 + 统一评测口径（全项目共用）

第六周作业的起点是一个「结论」和一个「怀疑」：
  课件结论：TNEWS 15 类短文本上，判别式微调（BERT 0.544）> 生成式零样本（0.105），
            TF-IDF（0.472）是便宜的下限，本地 0.6B 零样本不可用。
  怀疑：这个排序是**任务特性**，还是**这一份数据 + 这一个模型**的偶然？

要排除偶然，就得在两个正交维度上各换一次：
  ① 换预训练模型（数据集不动）—— 看「预训练质量/模型容量」贡献多少；
  ② 换数据集（模型不动）—— 看「方法排序」跨任务是否稳定。

本文件负责把两件事抽象成一套接口，让后面所有方法脚本只写一行
`load_clean("thucnews", n=500)` 就能换数据集，指标口径完全一致。

用法：
  from common.datasets import load_clean, LABELS_OF, DATASETS
  samples, meta = load_clean("tnews", n=500)
"""

import json
import random
from pathlib import Path

CODE_ROOT = Path(__file__).resolve().parent.parent
DATA_ROOT = CODE_ROOT / "data"

# ── 数据集一：TNEWS（课件同款，15 类中文新闻标题）
TNEWS_LABELS = ["故事", "文化", "娱乐", "体育", "财经",
                "房产", "汽车", "教育", "科技", "军事",
                "旅游", "国际", "证券", "农业", "电竞"]

DATASETS = {
    "tnews": {
        "dir": "tnews",
        "labels": TNEWS_LABELS,
        "desc": "TNEWS / CLUE，15 类中文新闻短文本，train 53,360 / val 10,000",
        # 课件实测：val 里 1099 条与 train 完全重复（11%），不去重会虚高 TF-IDF
        "known_leak": "11% 验证样本与训练集重复，必须去重后再横向比较",
    },
    "thucnews": {
        "dir": "thucnews",
        "labels": None,          # 从 labels.json 读，避免写两遍
        "desc": "THUCNews 标题 14 类（每类 1,800 训练 / 150 验证，seed=42 抽样）",
        "known_leak": "抓取时已按标题去重、按类分层划分，理论无重叠；仍跑同一套去重口径做兜底",
    },
}

LABELS_OF = {}


def _labels_of(name: str):
    """类别名列表（THUCNews 从 labels.json 读，保证和生成数据时一致）"""
    if name in LABELS_OF:
        return LABELS_OF[name]
    cfg = DATASETS[name]
    if cfg["labels"] is not None:
        labels = cfg["labels"]
    else:
        labels = json.loads((DATA_ROOT / cfg["dir"] / "labels.json").read_text(encoding="utf-8"))
    LABELS_OF[name] = labels
    return labels


def load_splits(name: str):
    """返回 (train, val)，每条 {"sentence", "label"}"""
    d = DATA_ROOT / DATASETS[name]["dir"]
    train = json.loads((d / "train.json").read_text(encoding="utf-8"))
    val = json.loads((d / "val.json").read_text(encoding="utf-8"))
    return train, val


def clean_val(train, val):
    """
    剔除与训练集**整句完全相同**的验证样本，返回 (clean, n_dup)。

    这个口径照搬课件：所有方法必须跑在同一批干净样本上，否则
    「TF-IDF 靠词面匹配背答案」会把差距抹平，横向对比失去意义。
    """
    seen = {d["sentence"] for d in train}
    clean = [d for d in val if d["sentence"] not in seen]
    return clean, len(val) - len(clean)


def sample_subset(items, n, seed=42):
    """固定 seed 抽样：换模型 / 换数据集之后，同数据集内的所有方法仍共享同一批样本"""
    if n >= len(items) or n <= 0:
        return list(items)
    return random.Random(seed).sample(items, n)


def load_clean(name: str, n=None, seed=42):
    """最常用入口：读数据 → 去重 →（可选）抽样 → 返回 (samples, meta)"""
    train, val = load_splits(name)
    clean, n_dup = clean_val(train, val)
    samples = sample_subset(clean, n or len(clean), seed)
    meta = {
        "dataset": name,
        "n_train": len(train),
        "n_val": len(val),
        "n_dup": n_dup,
        "dup_rate": round(n_dup / len(val), 4) if val else 0.0,
        "n_clean": len(clean),
        "n_eval": len(samples),
        "n_labels": len(_labels_of(name)),
        "seed": seed,
    }
    return samples, meta


def label_names(name: str):
    return _labels_of(name)


def num_labels(name: str):
    return len(_labels_of(name))


if __name__ == "__main__":
    # 自检：两套数据集的规模、去重率、类别数一次看清
    for k in DATASETS:
        samples, meta = load_clean(k, n=500)
        print(f"{k:<10} {DATASETS[k]['desc']}")
        print(f"           {meta}")
