"""
汇总 + 出图：把 outputs/ 下所有 pred_*.json 拉成一张可比的表

为什么要单独一个脚本而不是手工抄数：
  ① 数字必须能追溯到「哪份文件 + 哪次运行」，抄一次就断一次链；
  ② 两个数据集的类别数不同（15 vs 14），随机基线不同，必须由脚本按 1/C 算；
  ③ 换模型/换数据集之后要看的不是单个分数，而是**排序是否稳定**——
     这一步靠人眼看表格容易只看最大值，用脚本把「同列排名」也算出来。

产物：
  outputs/summary.md          主表（Markdown，可直接贴文档）
  outputs/fig_*.png           图（实验A / 实验B / 数据量曲线 / 混淆矩阵）
"""

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

CODE_ROOT = Path(__file__).resolve().parent.parent
OUT = CODE_ROOT / "outputs"

# 展示名（比文件名好看，且固定顺序，便于横向对比）
PRETTY = {
    "rule_keyword": "规则 / 关键词",
    "tfidf_svm": "TF-IDF + LinearSVC",
    "finetune:bert-base-chinese": "BERT-base-chinese 微调",
    "finetune:chinese-roberta-wwm-ext": "RoBERTa-wwm-ext 微调",
    "finetune:chinese-macbert-base": "MacBERT-base 微调",
    "finetune:chinese-rbt3": "RBT3（3 层）微调",
    "qwen3_zero_shot": "Qwen3-0.6B zero-shot",
}
ORDER = list(PRETTY.values())


def load_all():
    rows = []
    for p in sorted(OUT.glob("pred_*.json")):
        if p.name.startswith("pred_ckpt"):
            continue
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"[warn] {p.name} 读取失败：{e}")
            continue
        r = d.get("report", {})
        if "method" not in r:
            continue
        rows.append({"file": p.name, "report": r, "meta": d.get("meta", {})})
    return rows


def frac_of(rep):
    """这条结果用了多少训练数据（1.0 = 全量）。图里只画全量，避免数据量点把柱状图盖掉。"""
    f = rep.get("train_frac") or rep.get("hyper", {}).get("train_frac")
    return 1.0 if f is None else float(f)


def fmt(v, nd=4):
    if v is None:
        return "-"
    if isinstance(v, float):
        return f"{v:.{nd}f}"
    return str(v)


def main_table(rows):
    """主表：按数据集分组，每个数据集内按 Macro-F1 降序（顺便看排序稳不稳）"""
    by_ds = {}
    for row in rows:
        r = row["report"]
        by_ds.setdefault(r.get("dataset", "?"), []).append(row)

    lines = []
    for ds, rs in by_ds.items():
        rs.sort(key=lambda x: -(x["report"].get("macro_f1") or 0))
        n_cls = rs[0]["meta"].get("n_labels") or len(rs[0]["report"].get("per_class_recall", {}))
        lines.append(f"\n### 数据集 `{ds}`（{n_cls} 类，随机基线 Acc={1 / n_cls:.4f}）\n")
        lines.append("| 排名 | 方法 | 训练量 | 准确率(含失败) | Macro-F1 | ECE(校准) | 训练耗时 | 峰值显存 | 参数量 | 结果文件 |")
        lines.append("|---|---|---|---|---|---|---|---|---|---|")
        for i, row in enumerate(rs, 1):
            r = row["report"]
            acc = r.get("acc_incl_unparsed", r.get("acc"))
            secs = r.get("train_seconds", r.get("fit_seconds"))
            sec_txt = f"{secs}s" if secs is not None else "—"
            mem = r.get("peak_gpu_gb")
            mem_txt = f"{mem}GB" if mem else "—"
            pars = r.get("params_total")
            par_txt = f"{pars / 1e6:.1f}M" if pars else "—"
            # 训练量：TF-IDF 直接写在 report 里，微调结果写在 hyper 里（早期版本没写，从文件名兜底）
            frac = r.get("train_frac") or r.get("hyper", {}).get("train_frac")
            if frac is None and "_frac" in row["file"]:
                frac = float(row["file"].split("_frac")[1].split(".")[0])
            frac_txt = "100%" if frac in (None, 1.0) else f"{frac:.0%}"
            lines.append(f"| {i} | {PRETTY.get(r['method'], r['method'])} | {frac_txt} | {fmt(acc)} | "
                         f"{fmt(r.get('macro_f1'))} | {fmt(r.get('ece'))} | {sec_txt} | {mem_txt} | "
                         f"{par_txt} | `{row['file']}` |")
    return "\n".join(lines)


def fig_model_compare(rows):
    """实验 A：同数据集、同超参，只换预训练模型"""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
    plt.rcParams["axes.unicode_minus"] = False

    order = ["bert-base-chinese", "chinese-roberta-wwm-ext", "chinese-macbert-base", "chinese-rbt3"]
    name_map = {"bert-base-chinese": "BERT-base", "chinese-roberta-wwm-ext": "RoBERTa-wwm",
                "chinese-macbert-base": "MacBERT", "chinese-rbt3": "RBT3(3层)"}
    ds_list = sorted({r["report"].get("dataset") for r in rows})
    data = {bb: [None] * len(ds_list) for bb in order}
    for r in rows:
        rep = r["report"]
        if frac_of(rep) < 1.0:      # 只画全量训练，15%/50% 的点归数据量曲线那张图
            continue
        bb = rep.get("backbone")
        if bb in data and rep.get("dataset") in ds_list:
            data[bb][ds_list.index(rep["dataset"])] = rep.get("macro_f1")

    fig, axes = plt.subplots(1, len(ds_list), figsize=(6 * len(ds_list), 4.2), squeeze=False)
    for j, ds in enumerate(ds_list):
        ax = axes[0][j]
        vals = [data[bb][j] or 0 for bb in order]
        bars = ax.bar([name_map[b] for b in order], vals,
                      color=["#2D85AB" if b != "chinese-rbt3" else "#E8A33D" for b in order])
        for b, v in zip(bars, vals):
            ax.text(b.get_x() + b.get_width() / 2, v + 0.005, f"{v:.3f}", ha="center", fontsize=9)
        ax.set_title(f"{ds}：只换预训练模型（同超参/同数据/同 seed）")
        ax.set_ylabel("Macro-F1")
        ax.set_ylim(0, max(vals) * 1.25 if max(vals) else 1)
    plt.tight_layout()
    p = OUT / "fig_exp_a_backbones.png"
    plt.savefig(p, dpi=160)
    plt.close()
    return p


def fig_method_compare(rows):
    """实验 B：每种方法在两套数据集上的表现"""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
    plt.rcParams["axes.unicode_minus"] = False

    ds_list = sorted({r["report"].get("dataset") for r in rows})
    methods = [m for m in ORDER if any(r["report"].get("method") ==
                                      [k for k, v in PRETTY.items() if v == m][0] for r in rows)]
    lookup = {}
    for r in rows:
        rep = r["report"]
        if frac_of(rep) < 1.0:
            continue
        lookup[(PRETTY.get(rep["method"], rep["method"]), rep.get("dataset"))] = rep.get("macro_f1")

    # 每个数据集一张子图、y 轴各自自适应：
    # 两套数据集的绝对水平差得太远（0.09 vs 0.87），同一个轴会把 TNEWS 的组内排序压成平的。
    # 跨数据集的「水平差」由主表和 exp_a 图表达，这张图专门回答「排序稳不稳」。
    fig, axes = plt.subplots(1, len(ds_list), figsize=(6.2 * len(ds_list), 4.8), squeeze=False)
    for j, ds in enumerate(ds_list):
        ax = axes[0][j]
        vals = [lookup.get((m, ds)) or 0 for m in methods]
        order = np.argsort(vals)[::-1]          # 组内按分数降序，一眼看出排名
        bars = ax.bar([methods[i] for i in order], [vals[i] for i in order],
                      color=["#2D85AB" if "微调" in methods[i] else "#E8A33D" for i in order])
        for b in bars:
            ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.004,
                    f"{b.get_height():.3f}", ha="center", fontsize=8)
        ax.set_title(f"{ds}：方法排序（按 Macro-F1）")
        ax.set_ylabel("Macro-F1")
        ax.tick_params(axis="x", rotation=30, labelsize=8)
        if max(vals) > 0:
            ax.set_ylim(min(vals) * 0.9 if min(vals) > 0.3 else 0, max(vals) * 1.12)
    plt.tight_layout()
    p = OUT / "fig_exp_b_methods.png"
    plt.savefig(p, dpi=160)
    plt.close()
    return p


def fig_data_volume(rows):
    """数据量曲线：TF-IDF 与 BERT 的差距随训练量怎么变（验证「小样本时谁更强」）"""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
    plt.rcParams["axes.unicode_minus"] = False

    points = {}
    for r in rows:
        rep = r["report"]
        # 显式检查 train_frac 是否出现过（全量结果默认 1.0，也要作为曲线终点）
        raw = rep.get("train_frac", rep.get("hyper", {}).get("train_frac"))
        if raw is None:
            raw = 1.0
        key = (rep.get("dataset"), rep["method"])
        points.setdefault(key, {})[float(raw)] = rep.get("macro_f1")
    if not points:
        return None

    # 只有 1 个数据点的曲线（规则法不随训练量变）放进曲线图只会压扁 y 轴，直接滤掉
    points = {k: v for k, v in points.items() if len(v) >= 2}
    if not points:
        return None
    ds_list = sorted({k[0] for k in points})
    fig, axes = plt.subplots(1, len(ds_list), figsize=(6 * len(ds_list), 4.2), squeeze=False)
    for j, ds in enumerate(ds_list):
        ax = axes[0][j]
        for method, pts in points.items():
            if method[0] != ds:
                continue
            xs = sorted(pts)
            # x 用**数值**而不是百分比字符串：字符串会被 matplotlib 当类别，
            # 顺序取决于首次绘制顺序，15/50/100 会被画成 15/100/50（踩过）
            ax.plot([x * 100 for x in xs], [pts[x] for x in xs], "o-",
                    label=PRETTY.get(method[1], method[1]))
        ax.set_xticks([15, 50, 100])
        ax.set_xticklabels(["15%", "50%", "100%"])
        ax.set_title(f"{ds}：不同训练量下的 Macro-F1")
        ax.set_ylabel("Macro-F1")
        ax.set_xlabel("训练集使用比例")
        ax.legend(fontsize=8)
    plt.tight_layout()
    p = OUT / "fig_data_volume.png"
    plt.savefig(p, dpi=160)
    plt.close()
    return p


def fig_confusion(rows, ds, top=True):
    """混淆矩阵：挑该数据集 F1 最高/最低的两个 BERT 模型看错误集中在哪里"""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
    plt.rcParams["axes.unicode_minus"] = False
    from common.datasets import label_names

    cand = [r for r in rows if r["report"].get("dataset") == ds
            and r["report"]["method"].startswith("finetune:")]
    if not cand:
        return None
    cand.sort(key=lambda x: -(x["report"].get("macro_f1") or 0))
    pick = cand[0] if top else cand[-1]
    cm = np.array(pick["report"]["confusion_matrix"], dtype=float)
    cm_n = cm / np.maximum(cm.sum(1, keepdims=True), 1)
    labels = label_names(ds)
    fig, ax = plt.subplots(figsize=(7.5, 6.5))
    im = ax.imshow(cm_n, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(len(labels)))
    ax.set_yticks(range(len(labels)))
    ax.set_xticklabels(labels, rotation=90, fontsize=8)
    ax.set_yticklabels(labels, fontsize=8)
    ax.set_xlabel("预测")
    ax.set_ylabel("真实")
    ax.set_title(f"{ds} · {PRETTY.get(pick['report']['method'], '')} 归一化混淆矩阵")
    fig.colorbar(im, ax=ax, fraction=0.046)
    plt.tight_layout()
    p = OUT / f"fig_confusion_{ds}_{'best' if top else 'worst'}.png"
    plt.savefig(p, dpi=160)
    plt.close()
    return p


def main():
    rows = load_all()
    if not rows:
        print("outputs/ 下还没有 pred_*.json，先跑实验脚本")
        return
    print(f"读到 {len(rows)} 份结果：{[r['file'] for r in rows]}")

    md = ["# 第六周作业：换预训练模型 / 换数据集 的分类对比实验", "",
          "> 全部数字由 `report/make_report.py` 从 `outputs/pred_*.json` 自动汇总，",
          "> 每行都标了来源文件，可逐条回溯到具体一次运行。", "",
          "## 一、主表（按数据集分组，组内按 Macro-F1 降序）", main_table(rows), ""]

    figs = []
    for fn, desc in [(fig_model_compare, "实验 A：只换预训练模型"),
                     (fig_method_compare, "实验 B：方法 × 数据集"),
                     (fig_data_volume, "数据量实验")]:
        try:
            p = fn(rows)
            if p:
                figs.append((p, desc))
        except Exception as e:
            print(f"[warn] {fn.__name__} 失败：{e}")
    for ds in sorted({r["report"].get("dataset") for r in rows}):
        try:
            p = fig_confusion(rows, ds)
            if p:
                figs.append((p, f"{ds} 混淆矩阵（该数据集最好的微调模型）"))
        except Exception as e:
            print(f"[warn] confusion {ds}: {e}")

    if figs:
        md += ["## 二、图", ""]
        for p, desc in figs:
            md += [f"### {desc}", "", f"![{desc}]({p.name})", ""]

    (OUT / "summary.md").write_text("\n".join(md), encoding="utf-8")
    print(f"→ {OUT / 'summary.md'}")

    # 控制台也打一份精简表，跑完立刻能看
    for r in sorted(rows, key=lambda x: (x["report"].get("dataset", ""), -(x["report"].get("macro_f1") or 0))):
        rep = r["report"]
        print(f"{rep.get('dataset'):<10} {PRETTY.get(rep['method'], rep['method']):<28} "
              f"acc={fmt(rep.get('acc_incl_unparsed', rep.get('acc')))} f1={fmt(rep.get('macro_f1'))}")


if __name__ == "__main__":
    main()
