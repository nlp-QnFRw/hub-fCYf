# 第六周作业：换预训练模型 / 换数据集 的分类对比实验

> 全部数字由 `report/make_report.py` 从 `outputs/pred_*.json` 自动汇总，
> 每行都标了来源文件，可逐条回溯到具体一次运行。

## 一、主表（按数据集分组，组内按 Macro-F1 降序）

### 数据集 `thucnews`（14 类，随机基线 Acc=0.0714）

| 排名 | 方法 | 训练量 | 准确率(含失败) | Macro-F1 | ECE(校准) | 训练耗时 | 峰值显存 | 参数量 | 结果文件 |
|---|---|---|---|---|---|---|---|---|---|
| 1 | MacBERT-base 微调 | 100% | 0.9640 | 0.8967 | 0.0341 | 201.6s | 2.92GB | 102.3M | `pred_thucnews_chinese-macbert-base.json` |
| 2 | BERT-base-chinese 微调 | 100% | 0.9620 | 0.8944 | 0.0173 | 189.4s | 2.93GB | 102.3M | `pred_thucnews_bert-base-chinese.json` |
| 3 | RoBERTa-wwm-ext 微调 | 100% | 0.9620 | 0.8942 | 0.0258 | 193.2s | 2.92GB | 102.3M | `pred_thucnews_chinese-roberta-wwm-ext.json` |
| 4 | RBT3（3 层）微调 | 100% | 0.9400 | 0.8749 | 0.0148 | 65.2s | 0.94GB | 38.5M | `pred_thucnews_chinese-rbt3.json` |
| 5 | TF-IDF + LinearSVC | 100% | 0.9360 | 0.8723 | - | 1.0s | — | — | `pred_thucnews_tfidf.json` |
| 6 | BERT-base-chinese 微调 | 15% | 0.9320 | 0.8673 | 0.0174 | 33.5s | 2.92GB | 102.3M | `pred_thucnews_bert-base-chinese_frac0.15.json` |
| 7 | TF-IDF + LinearSVC | 50% | 0.9200 | 0.8575 | - | 0.5s | — | — | `pred_thucnews_tfidf_frac0.5.json` |
| 8 | TF-IDF + LinearSVC | 15% | 0.8880 | 0.8272 | - | 0.2s | — | — | `pred_thucnews_tfidf_frac0.15.json` |
| 9 | Qwen3-0.6B zero-shot | 100% | 0.2040 | 0.1531 | - | — | — | — | `pred_thucnews_zeroshot.json` |
| 10 | 规则 / 关键词 | 100% | 0.1180 | 0.0899 | - | — | — | — | `pred_thucnews_rule.json` |

### 数据集 `tnews`（15 类，随机基线 Acc=0.0667）

| 排名 | 方法 | 训练量 | 准确率(含失败) | Macro-F1 | ECE(校准) | 训练耗时 | 峰值显存 | 参数量 | 结果文件 |
|---|---|---|---|---|---|---|---|---|---|
| 1 | RoBERTa-wwm-ext 微调 | 100% | 0.5660 | 0.5582 | 0.1155 | 406.4s | 2.92GB | 102.3M | `pred_tnews_chinese-roberta-wwm-ext.json` |
| 2 | BERT-base-chinese 微调 | 100% | 0.5500 | 0.5476 | 0.1188 | 406.8s | 2.92GB | 102.3M | `pred_tnews_bert-base-chinese.json` |
| 3 | MacBERT-base 微调 | 100% | 0.5540 | 0.5471 | 0.1309 | 415.4s | 2.92GB | 102.3M | `pred_tnews_chinese-macbert-base.json` |
| 4 | BERT-base-chinese 微调 | 15% | 0.5460 | 0.5420 | 0.1291 | 64.2s | 2.93GB | 102.3M | `pred_tnews_bert-base-chinese_frac0.15.json` |
| 5 | RBT3（3 层）微调 | 100% | 0.5340 | 0.5257 | 0.1097 | 140.2s | 0.94GB | 38.5M | `pred_tnews_chinese-rbt3.json` |
| 6 | TF-IDF + LinearSVC | 15% | 0.5180 | 0.4792 | - | 0.5s | — | — | `pred_tnews_tfidf_frac0.15.json` |
| 7 | TF-IDF + LinearSVC | 100% | 0.5120 | 0.4721 | - | 5.4s | — | — | `pred_tnews_tfidf.json` |
| 8 | TF-IDF + LinearSVC | 50% | 0.5140 | 0.4642 | - | 1.9s | — | — | `pred_tnews_tfidf_frac0.5.json` |
| 9 | Qwen3-0.6B zero-shot | 100% | 0.1700 | 0.1057 | - | — | — | — | `pred_tnews_zeroshot.json` |
| 10 | 规则 / 关键词 | 100% | 0.1260 | 0.0716 | - | — | — | — | `pred_tnews_rule.json` |

## 二、图

### 实验 A：只换预训练模型

![实验 A：只换预训练模型](fig_exp_a_backbones.png)

### 实验 B：方法 × 数据集

![实验 B：方法 × 数据集](fig_exp_b_methods.png)

### 数据量实验

![数据量实验](fig_data_volume.png)

### thucnews 混淆矩阵（该数据集最好的微调模型）

![thucnews 混淆矩阵（该数据集最好的微调模型）](fig_confusion_thucnews_best.png)

### tnews 混淆矩阵（该数据集最好的微调模型）

![tnews 混淆矩阵（该数据集最好的微调模型）](fig_confusion_tnews_best.png)
