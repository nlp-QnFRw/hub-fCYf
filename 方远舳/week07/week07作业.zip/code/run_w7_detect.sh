#!/usr/bin/env bash
# 实验 C：换任务（事件检测）——A 实验跑完后执行
set -u
PY=/e/PyTorch/conda_envs/py312/python.exe
M="E:/大模型课程/6/作业_换模型换数据集/pretrain_models"
cd "$(dirname "$0")"
for bb in bert-base-chinese chinese-macbert-base; do
  echo "=== [$(date +%H:%M:%S)] detect $bb"
  $PY -u detect/train_detect.py --bert_path "$M/$bb" --run_name "detect_$bb" \
      > "outputs/logs/detect_$bb.log" 2>&1
done
echo "DETECT DONE $(date)"
