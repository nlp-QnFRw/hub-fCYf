"""
方法族全景表：把「判别式 / 生成式 / 检测任务」三类结果拉到同一张表上

为什么需要这张表：
  单看「换基座的 4 行」只能回答「哪个基座好」，回答不了作业要求的
  「各种方法的差异」——规则、BiLSTM-CRF、BERT、CRF、流水线、LLM 零样本/少样本/LoRA
  是六个不同层次的做法，各自的代价和收益必须并排才看得出取舍。

三条铁律（表里也标了）：
  1. 不同 n 的结果不能直接比。LLM 链路只在 n=200 的子集上跑过，
     所以表里给出判别式方法在**同一批 n=200 样本**上的投影列，只有这两列可比。
  2. 检测任务的 F1 和抽取任务的 F1 不是一回事，分表放，不混排。
  3. 每个数字都带来源文件，不手抄。

用法：
  python eval/compare_all_methods.py
"""

import json
import os
import sys
from pathlib import Path

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

ROOT = Path(__file__).resolve().parents[1]
DISC = ROOT / "outputs" / "metrics" / "disc"
LLM = ROOT / "outputs" / "metrics" / "llm"
DET = ROOT / "outputs" / "metrics" / "detect"
OUT = ROOT / "outputs" / "metrics" / "compare_all_methods.md"

# (文件前缀, 展示名, 层次说明)
DISC_METHODS = [
    ("rule", "规则（词典+正则）", "L0 零训练基线"),
    ("bilstm_crf", "BiLSTM-CRF（字符级，无预训练）", "L1 无预训练"),
    ("bert_linear_256", "BERT+Linear（联合 149 标签）", "L2 判别式主线"),
    ("bert_crf_256", "BERT+CRF（联合 149 标签）", "L2 + 序列约束"),
    ("pipeline", "两段式流水线（检测→类型→论元）", "L2 结构拆分"),
    ("pipeline_oracle_type", "两段式·类型给金标（上界）", "L2 上界参考"),
]

BACKBONES = ["bert-base-chinese", "chinese-roberta-wwm-ext",
             "chinese-macbert-base", "chinese-rbt3"]

LLM_METHODS = [
    ("local_zero_n60", "本地 Qwen3-0.6B 零样本", "L3 生成式零样本（本地）"),
    ("api_zero_n200", "API 零样本", "L3 生成式零样本（外部大模型）"),
    ("api_few_n200", "API 少样本（few-shot）", "L3 生成式少样本"),
    ("sft_lora_n200", "Qwen3-0.6B + LoRA SFT", "L4 生成式微调"),
]


def load_metric(p: Path):
    if not p.exists():
        return None
    d = json.loads(p.read_text(encoding="utf-8"))
    if "trigger" in d:                       # 判别式 / LLM 格式
        return {"trigger": d["trigger"]["f1"], "argument": d["argument"]["f1"],
                "event": d["event_exact"]["f1"], "n": d.get("num_samples")}
    return None


def main():
    md = ["# 第七周作业：信息抽取 —— 方法族全景对比\n"]

    # ── 表 1：抽取任务（n=930 全量 dev）
    md += ["## 表 1 · 事件抽取（dev_extract_clean，930 句）\n",
           "| 层次 | 方法 | trigger F1 | argument F1 | event F1 | 来源 |",
           "|---|---|---|---|---|---|"]
    for key, name, layer in DISC_METHODS:
        m = load_metric(DISC / f"{key}.json")
        if not m:
            md.append(f"| {layer} | {name} | 未跑 | 未跑 | 未跑 | — |")
            continue
        md.append(f"| {layer} | {name} | {m['trigger']:.4f} | {m['argument']:.4f} | "
                  f"{m['event']:.4f} | `{key}.json` |")

    # ── 表 2：换基座（作业主实验）
    md += ["\n## 表 2 · 换预训练基座（同超参，只换 --bert_path）\n",
           "| 基座 | trigger F1 | argument F1 | event F1 | 来源 |",
           "|---|---|---|---|---|"]
    for bb in BACKBONES:
        key = f"bert_linear_256_{bb}"
        m = load_metric(DISC / f"{key}.json")
        if not m:
            md.append(f"| {bb} | 未跑 | 未跑 | 未跑 | — |")
            continue
        md.append(f"| {bb} | {m['trigger']:.4f} | {m['argument']:.4f} | {m['event']:.4f} | `{key}.json` |")

    # ── 表 3：生成式链路（n=200 子集）
    md += ["\n## 表 3 · 生成式链路（n=200 子集；与下方判别式投影列同批样本才可比）\n",
           "| 层次 | 方法 | trigger F1 | argument F1 | event F1 | 来源 |",
           "|---|---|---|---|---|---|"]
    for key, name, layer in LLM_METHODS:
        m = load_metric(LLM / f"{key}.json")
        if not m:
            md.append(f"| {layer} | {name} | 未跑 | 未跑 | 未跑 | — |")
            continue
        md.append(f"| {layer} | {name} | {m['trigger']:.4f} | {m['argument']:.4f} | "
                  f"{m['event']:.4f} | `{key}.json` |")
    for bb in BACKBONES:
        # 基线那次跑得早，文件名没有后缀；换基座的几次统一带了模型名
        key = "bert_linear_256_n200" if bb == "bert-base-chinese" else f"bert_linear_256_{bb}_n200"
        m = load_metric(DISC / f"{key}.json")
        if m:
            md.append(f"| 判别式参照 | BERT+Linear（{bb}）@n200 | {m['trigger']:.4f} | "
                      f"{m['argument']:.4f} | {m['event']:.4f} | `{key}.json` |")

    # ── 表 4：换任务（事件检测）
    md += ["\n## 表 4 · 换任务：事件检测（句子级多标签，train 32,794 / dev 4,815）\n",
           "| 基座 | micro-F1 | macro-F1 | 有无事件 F1 | 来源 |",
           "|---|---|---|---|---|"]
    for p in sorted(DET.glob("detect_*.json")):
        if "smoke" in p.name:
            continue
        d = json.loads(p.read_text(encoding="utf-8"))
        md.append(f"| {Path(d['bert_path']).name} | {d['micro_f1']:.4f} | {d['macro_f1']:.4f} | "
                  f"{d['has_event_f1']:.4f} | `{p.name}` |")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join(md), encoding="utf-8")
    print("\n".join(md))
    print(f"\n→ {OUT}")


if __name__ == "__main__":
    main()
