"""
换基座对比（事件抽取）：ΔF1 + 配对 bootstrap 95% 区间 + 逐类/逐角色差异

作业的三个问题必须能被这张表回答：
  谁更好？  → trigger / argument / event 三级 F1 并排
  差得算不算真？ → 同一批 930 条 dev 上做配对 bootstrap（2000 次），看 ΔF1 的 95% 区间是否跨 0
  差在哪？  → 逐事件类型的 F1 变化 + 逐角色的论元 F1 变化

为什么用配对 bootstrap 而不是直接比两个数：
  事件抽取的 F1 是「事件数加权」的 micro 指标，一句长公告能贡献十几个论元。
  换基座带来的差异往往只由几十条样本翻转造成——不做区间估计就会把噪声当成提升。
  （这条纪律在第六周已经吃过一次亏：500 条抽样让排序都翻了。）

用法：
  python eval/compare_backbones.py
  python eval/compare_backbones.py --baseline bert_linear_256_bert-base-chinese
"""

import argparse
import csv
import json
import os
import sys
from collections import defaultdict
from pathlib import Path

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "common"))

from evaluate_events import as_event_list, compare_events, load_jsonl, row_key  # noqa: E402

METRIC_DIR = ROOT / "outputs" / "metrics" / "disc"
DISC_DIR = ROOT / "outputs" / "disc"
OUT = ROOT / "outputs" / "metrics" / "compare_backbones.md"


def per_sample_counts(gold_rows, pred_rows):
    """逐样本算 (trigger, argument, event) 的 tp/fp/fn，供 bootstrap 重采样用"""
    gmap = {row_key(r): r for r in gold_rows}
    out = []
    for p in pred_rows:
        k = row_key(p)
        g = gmap.get(k)
        if g is None:
            continue
        # 注意 gold 的字段是单数 "event"（一句一事件），预测是 "events" 列表——
        # 课件里的 as_event_list 就是干这个兼容的，别自己 get("events")，会静默拿到空列表
        tr, ar, ev = compare_events(as_event_list(g), as_event_list(p))
        out.append({"key": k, "tr": tr, "ar": ar, "ev": ev})
    return out


def f1_from_counts(counts, idx):
    tp = sum(c[idx][0] for c in counts)
    fp = sum(c[idx][1] for c in counts)
    fn = sum(c[idx][2] for c in counts)
    return 2 * tp / max(2 * tp + fp + fn, 1e-9)


def paired_bootstrap(counts_a, counts_b, idx, n_boot=2000, seed=42):
    """同一批样本重采样，分别算两个模型的 F1，取差值的 95% 区间"""
    assert len(counts_a) == len(counts_b)
    rng = np.random.default_rng(seed)
    n = len(counts_a)
    a_x = np.array([c[idx] for c in counts_a], dtype=float)
    b_x = np.array([c[idx] for c in counts_b], dtype=float)

    def f1_of(x, sel):
        tp, fp, fn = x[sel, 0].sum(), x[sel, 1].sum(), x[sel, 2].sum()
        return 2 * tp / max(2 * tp + fp + fn, 1e-9)

    diffs = np.empty(n_boot)
    for i in range(n_boot):
        j = rng.integers(0, n, n)
        diffs[i] = f1_of(b_x, j) - f1_of(a_x, j)
    return float(np.percentile(diffs, 2.5)), float(np.percentile(diffs, 97.5)), float(diffs.mean())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--baseline", default="bert_linear_256_bert-base-chinese")
    ap.add_argument("--n_boot", type=int, default=2000)
    args = ap.parse_args()

    # 找「同名脚本 + 不同 --bert_path」产出的结果
    cands = sorted(p for p in METRIC_DIR.glob("bert_linear_256_*.json")
                   if "_n200" not in p.name and "INVALID" not in p.name)
    if not cands:
        raise SystemExit("还没有换基座的结果，先跑 bert/train.py --bert_path <模型目录>")

    rows, payloads = [], {}
    for p in cands:
        d = json.loads(p.read_text(encoding="utf-8"))
        tag = p.stem
        # metrics JSON 里没有存 bert_path（课件脚本只记 display_name），
        # 所以基座名从 run_name 前缀里取：bert_linear_256_<backbone>
        short = tag.replace("bert_linear_256_", "", 1)
        rows.append({
            "tag": tag, "backbone": short,
            "trigger_f1": d["trigger"]["f1"], "argument_f1": d["argument"]["f1"],
            "event_f1": d["event_exact"]["f1"],
            "params_M": (d.get("meta") or {}).get("params_m"),
            "elapsed_s": round((d.get("meta") or {}).get("train_s", 0)) or None,
            "n": d.get("num_samples"),
        })
        # 用 metrics JSON 里记录的 gold/pred 路径（它才是这次评测真正用的那一份）
        pred_p = Path(d.get("pred") or (DISC_DIR / f"pred_{tag}.jsonl"))
        gold_p = Path(d.get("gold") or (ROOT / "data" / "processed" / "dev_extract_clean.jsonl"))
        if pred_p.exists() and gold_p.exists():
            payloads[tag] = per_sample_counts(load_jsonl(gold_p), load_jsonl(pred_p))

    base_tag = args.baseline if args.baseline in payloads else rows[0]["tag"]
    base = next(r for r in rows if r["tag"] == base_tag)

    md = ["# 换基座对比（事件抽取 · DuEE-Fin dev 930 条）\n",
          f"基线：`{base['backbone']}`（trigger {base['trigger_f1']} / argument {base['argument_f1']} / "
          f"event {base['event_f1']}）\n",
          "口径：同一份 train_extract 5,747 句、同一批 dev_extract_clean 930 句、同一套超参"
          "（lr 2e-5、头×5、batch 32、max_len 256、3 epoch、seed 42），**只换 --bert_path**。\n",
          "| 基座 | 参数量 | trigger F1 | argument F1 | event F1 | Δevent | 95% 区间 | 显著? | 耗时 |",
          "|---|---|---|---|---|---|---|---|---|"]

    out_rows = []
    for r in sorted(rows, key=lambda x: -x["event_f1"]):
        d_ev = r["event_f1"] - base["event_f1"]
        ci, sig = "—", "—"
        if r["tag"] in payloads and base_tag in payloads and r["tag"] != base_tag:
            lo, hi, _ = paired_bootstrap(payloads[base_tag], payloads[r["tag"]], "ev", args.n_boot)
            ci = f"[{lo:+.4f}, {hi:+.4f}]"
            sig = "**是**" if (lo > 0 or hi < 0) else "否（跨 0）"
        md.append(f"| {r['backbone']} | {r['params_M']}M | {r['trigger_f1']} | {r['argument_f1']} | "
                  f"{r['event_f1']} | {d_ev:+.4f} | {ci} | {sig} | "
                  f"{r['elapsed_s'] if r['elapsed_s'] else '—'}s |")
        out_rows.append({**r, "delta_event_f1": round(d_ev, 4), "ci_low": ci, "significant": sig})

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join(md), encoding="utf-8")
    with open(OUT.with_suffix(".csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(out_rows[0]))
        w.writeheader()
        w.writerows(out_rows)

    print("\n".join(md))
    print(f"\n→ {OUT}")


if __name__ == "__main__":
    main()
