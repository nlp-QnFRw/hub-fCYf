#!/usr/bin/env bash
# 换 API 模型对照：deepseek-flash（官方） vs gpt-6.1-terra（中转）
# 同一个 prompt 模板、同一批 canonical_order 前 200 条（seed=42），只换后端模型
set -u
PY=/e/PyTorch/conda_envs/py312/python.exe
cd "$(dirname "$0")"
DS_KEY="sk-b83e41c38fb2443588f2868a8b4fc13b"
MID_KEY="sk-vZN5HwQOGXJ26jpGw9KML0suL9dLCLNEVNEDCzkDgNCrVOzt"

echo "=== [$(date +%H:%M:%S)] zero deepseek-flash n200"
LLM_API_KEY="$DS_KEY" LLM_BASE_URL="https://api.deepseek.com" \
  $PY llm_zero_shot/llm_extract.py --backend api --mode zero --n 200 \
  --model deepseek-flash --tag api_zero_n200_dsflash > outputs/logs/api_zero_dsflash.log 2>&1

echo "=== [$(date +%H:%M:%S)] few deepseek-flash n200"
LLM_API_KEY="$DS_KEY" LLM_BASE_URL="https://api.deepseek.com" \
  $PY llm_zero_shot/llm_extract.py --backend api --mode few --n 200 \
  --model deepseek-flash --tag api_few_n200_dsflash > outputs/logs/api_few_dsflash.log 2>&1

echo "=== [$(date +%H:%M:%S)] zero gpt-6.1-terra n200"
LLM_API_KEY="$MID_KEY" LLM_BASE_URL="https://code28.ccwu.cc/v1" \
  $PY llm_zero_shot/llm_extract.py --backend api --mode zero --n 200 \
  --model gpt-6.1-terra --tag api_zero_n200_gpt61 > outputs/logs/api_zero_gpt61.log 2>&1

echo "API COMPARE DONE $(date)"
