"""
实验 B：把「换数据集/换任务」这一维补上 —— 事件检测（句子级多标签分类）

为什么要做这一组：
  课件主线是**事件抽取**（trigger + 13 类论元 + 事件级精确匹配），标签空间 149 个，事件级 F1 只有 0.16 左右。
  这个数字低，到底是因为「模型不会抽论元」，还是因为「事件级是全字段精确匹配、要求太苛刻」？
  换到同一批语料的**前置任务**——事件检测（只判断这句话里有哪些事件类型，不抽 span）——
  就能把「识别难」和「匹配严」两件事分开：
    检测 F1 很高 → 模型认得事件类型，抽取的低分主要来自 span 对齐和论元缺失；
    检测 F1 也低 → 连类型都没学明白，抽取低分是上游问题。
  而且检测集比抽取集大 5.7 倍（32,794 vs 5,747），顺带回答了「数据量上来会不会不一样」。

任务定义：
  输入一句话 → 输出 13 个事件类型的存在与否（**多标签**，不是多分类）。
  一句公告常常同时含多个事件（"股东减持 + 解除质押"），按多分类做会把其中一个当噪声。

与抽取脚本的关系：
  完全独立的一个脚本，但它复用 common/ 的 model_paths 与日志约定，
  且评测口径同样落到「同一份 dev 集、同一个 seed」上，所以能和抽取任务横向比。

用法：
  python detect/train_detect.py --bert_path <模型目录> --run_name detect_bert
  python detect/train_detect.py --epochs 1 --max_steps 50 --device cpu   # 冒烟
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModel, AutoTokenizer, get_linear_schedule_with_warmup

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "common"))

from model_paths import BERT_MODEL_DIR, resolve_model_path  # noqa: E402

DATA = ROOT / "data" / "processed"
OUT_METRICS = ROOT / "outputs" / "metrics" / "detect"
OUT_LOGS = ROOT / "outputs" / "logs"


def load_jsonl(p):
    with open(p, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def build_labels(rows):
    """13 个事件类型，按出现频次降序固定下来（顺序固定才能跨 run 比较）"""
    from collections import Counter
    c = Counter()
    for r in rows:
        for t in r.get("types", []):
            c[t] += 1
    return [t for t, _ in c.most_common()]


class DetectDataset(Dataset):
    def __init__(self, rows, tok, label2id, max_len=128):
        self.rows, self.tok, self.label2id, self.max_len = rows, tok, label2id, max_len

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, i):
        r = self.rows[i]
        enc = self.tok(r["text"], truncation=True, max_length=self.max_len,
                       padding="max_length", return_tensors="pt")
        y = torch.zeros(len(self.label2id))
        for t in r.get("types", []):
            if t in self.label2id:
                y[self.label2id[t]] = 1.0
        return {"input_ids": enc["input_ids"][0], "attention_mask": enc["attention_mask"][0],
                "labels": y}


class DetectModel(nn.Module):
    """BERT + 一层多标签头（sigmoid + BCE）。不做 CRF：检测没有 span，不涉及序列合法性。"""

    def __init__(self, model_dir, n_labels, dropout=0.1):
        super().__init__()
        self.encoder = AutoModel.from_pretrained(str(model_dir))
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(self.encoder.config.hidden_size, n_labels)

    def forward(self, input_ids, attention_mask):
        out = self.encoder(input_ids=input_ids, attention_mask=attention_mask, return_dict=True)
        return self.classifier(self.dropout(out.last_hidden_state[:, 0]))


@torch.no_grad()
def evaluate(model, loader, device, thr=0.5):
    model.eval()
    probs, gts = [], []
    for b in loader:
        logits = model(b["input_ids"].to(device), b["attention_mask"].to(device))
        probs.append(torch.sigmoid(logits.float()).cpu().numpy())
        gts.append(b["labels"].numpy())
    P, G = np.vstack(probs), np.vstack(gts)
    pred = (P >= thr).astype(int)

    tp = (pred * G).sum(0)
    fp = (pred * (1 - G)).sum(0)
    fn = ((1 - pred) * G).sum(0)
    per_f1 = np.where(2 * tp + fp + fn > 0, 2 * tp / np.maximum(2 * tp + fp + fn, 1e-9), 0.0)

    # 句子级「有没有事件」——最实用的那个指标（分流第一步就是判有无）
    has_g, has_p = (G.sum(1) > 0).astype(int), (pred.sum(1) > 0).astype(int)
    tp_h = int(((has_p == 1) & (has_g == 1)).sum())
    fp_h = int(((has_p == 1) & (has_g == 0)).sum())
    fn_h = int(((has_p == 0) & (has_g == 1)).sum())

    return {
        "micro_f1": float(2 * tp.sum() / max(2 * tp.sum() + fp.sum() + fn.sum(), 1e-9)),
        "macro_f1": float(per_f1.mean()),
        "has_event_f1": float(2 * tp_h / max(2 * tp_h + fp_h + fn_h, 1e-9)),
        "per_type_f1": per_f1.tolist(),
        "_P": P, "_G": G,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bert_path", default="")
    ap.add_argument("--max_len", type=int, default=128)
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--batch_size", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--head_lr_mult", type=float, default=5.0)
    ap.add_argument("--warmup_ratio", type=float, default=0.1)
    ap.add_argument("--max_steps", type=int, default=0)
    ap.add_argument("--device", default="")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--run_name", default="detect")
    args = ap.parse_args()

    if not args.bert_path:
        args.bert_path = str(resolve_model_path(BERT_MODEL_DIR))
    device = args.device or ("cuda" if torch.cuda.is_available() else "cpu")
    torch.manual_seed(args.seed)
    random_seed = np.random.RandomState(args.seed)

    train = load_jsonl(DATA / "train_detect.jsonl")
    dev = load_jsonl(DATA / "dev_detect_clean.jsonl")
    labels = build_labels(train)
    label2id = {t: i for i, t in enumerate(labels)}
    print(f"[cfg] train={len(train)} dev={len(dev)} 类型={len(labels)} device={device}")
    print(f"[cfg] bert={args.bert_path}")

    tok = AutoTokenizer.from_pretrained(str(args.bert_path), use_fast=True)
    # 训练集切 10% 做内层验证（和抽取脚本同一套纪律：dev 只用于最终评测）
    idx = random_seed.permutation(len(train))
    n_inner = int(len(train) * 0.1)
    inner, tr = [train[i] for i in idx[:n_inner]], [train[i] for i in idx[n_inner:]]

    tr_dl = DataLoader(DetectDataset(tr, tok, label2id, args.max_len), batch_size=args.batch_size,
                       shuffle=True, num_workers=0)
    in_dl = DataLoader(DetectDataset(inner, tok, label2id, args.max_len), batch_size=64, num_workers=0)
    dev_dl = DataLoader(DetectDataset(dev, tok, label2id, args.max_len), batch_size=64, num_workers=0)

    model = DetectModel(args.bert_path, len(labels)).to(device)
    head = list(model.classifier.parameters()) + list(model.dropout.parameters())
    body = [p for n, p in model.named_parameters() if not n.startswith(("classifier", "dropout"))]
    opt = torch.optim.AdamW([{"params": body, "lr": args.lr},
                             {"params": head, "lr": args.lr * args.head_lr_mult}], weight_decay=0.01)

    steps = min(len(tr_dl), args.max_steps) if args.max_steps else len(tr_dl)
    total = steps * args.epochs
    sched = get_linear_schedule_with_warmup(opt, int(total * args.warmup_ratio), total)
    crit = nn.BCEWithLogitsLoss()
    scaler = torch.amp.GradScaler("cuda", enabled=(device == "cuda"))

    logs, best = [], -1
    t0 = time.time()
    for ep in range(1, args.epochs + 1):
        model.train()
        run, n = 0.0, 0
        for i, b in enumerate(tr_dl):
            opt.zero_grad(set_to_none=True)
            with torch.autocast("cuda", dtype=torch.float16, enabled=(device == "cuda")):
                loss = crit(model(b["input_ids"].to(device), b["attention_mask"].to(device)),
                            b["labels"].to(device))
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(opt)
            scaler.update()
            sched.step()
            run += loss.item()
            n += 1
            if i % 200 == 0:
                print(f"  ep{ep} step {i}/{steps} loss={loss.item():.4f}", flush=True)
            if args.max_steps and n >= args.max_steps:
                break
        inner_m = evaluate(model, in_dl, device)
        log = {"epoch": ep, "train_loss": round(run / max(n, 1), 4),
               "inner_micro_f1": round(inner_m["micro_f1"], 4),
               "inner_has_event_f1": round(inner_m["has_event_f1"], 4),
               "elapsed_s": round(time.time() - t0, 1)}
        logs.append(log)
        print(f"ep{ep}: inner micro_f1={log['inner_micro_f1']} has_event={log['inner_has_event_f1']} "
              f"({log['elapsed_s']}s)", flush=True)
        if inner_m["micro_f1"] > best:
            best = inner_m["micro_f1"]

    dev_m = evaluate(model, dev_dl, device)
    rep = {
        "method": "detect", "run_name": args.run_name, "bert_path": args.bert_path,
        "n_train": len(tr), "n_dev": len(dev), "labels": labels,
        "micro_f1": round(dev_m["micro_f1"], 4), "macro_f1": round(dev_m["macro_f1"], 4),
        "has_event_f1": round(dev_m["has_event_f1"], 4),
        "per_type_f1": {t: round(float(v), 4) for t, v in zip(labels, dev_m["per_type_f1"])},
        "params": int(sum(p.numel() for p in model.parameters())),
        "total_elapsed_s": round(time.time() - t0, 1),
        "epochs_log": logs,
        "args": vars(args),
    }
    OUT_METRICS.mkdir(parents=True, exist_ok=True)
    OUT_LOGS.mkdir(parents=True, exist_ok=True)
    (OUT_METRICS / f"{args.run_name}.json").write_text(
        json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
    np.savez(OUT_METRICS / f"{args.run_name}_probs.npz", P=dev_m["_P"], G=dev_m["_G"])
    print(f"\n[dev] micro_f1={rep['micro_f1']} macro_f1={rep['macro_f1']} "
          f"has_event_f1={rep['has_event_f1']} 耗时 {rep['total_elapsed_s']}s")
    print(f"→ {OUT_METRICS / (args.run_name + '.json')}")


if __name__ == "__main__":
    main()
