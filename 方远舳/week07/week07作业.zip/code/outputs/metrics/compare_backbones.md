# 换基座对比（事件抽取 · DuEE-Fin dev 930 条）

基线：`bert-base-chinese`（trigger 0.8293 / argument 0.5633 / event 0.1564）

口径：同一份 train_extract 5,747 句、同一批 dev_extract_clean 930 句、同一套超参（lr 2e-5、头×5、batch 32、max_len 256、3 epoch、seed 42），**只换 --bert_path**。

| 基座 | 参数量 | trigger F1 | argument F1 | event F1 | Δevent | 95% 区间 | 显著? | 耗时 |
|---|---|---|---|---|---|---|---|---|
| chinese-roberta-wwm-ext | 102.4M | 0.823 | 0.5613 | 0.1727 | +0.0163 | [-0.0019, +0.0337] | 否（跨 0） | 503s |
| bert-base-chinese | 102.4M | 0.8293 | 0.5633 | 0.1564 | +0.0000 | — | — | 1286s |
| chinese-macbert-base | 102.4M | 0.8122 | 0.5532 | 0.1535 | -0.0029 | [-0.0210, +0.0142] | 否（跨 0） | 501s |
| chinese-rbt3 | 38.6M | 0.7236 | 0.3615 | 0.0523 | -0.1041 | [-0.1261, -0.0831] | **是** | 144s |