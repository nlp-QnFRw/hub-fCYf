# 第七周作业：信息抽取 —— 方法族全景对比

## 表 1 · 事件抽取（dev_extract_clean，930 句）

| 层次 | 方法 | trigger F1 | argument F1 | event F1 | 来源 |
|---|---|---|---|---|---|
| L0 零训练基线 | 规则（词典+正则） | 0.6168 | 0.1740 | 0.0161 | `rule.json` |
| L1 无预训练 | BiLSTM-CRF（字符级，无预训练） | 0.8165 | 0.4634 | 0.0885 | `bilstm_crf.json` |
| L2 判别式主线 | BERT+Linear（联合 149 标签） | 0.8293 | 0.5630 | 0.1564 | `bert_linear_256.json` |
| L2 + 序列约束 | BERT+CRF（联合 149 标签） | 0.8320 | 0.5815 | 0.1697 | `bert_crf_256.json` |
| L2 结构拆分 | 两段式流水线（检测→类型→论元） | 0.6769 | 0.3690 | 0.0957 | `pipeline.json` |
| L2 上界参考 | 两段式·类型给金标（上界） | 0.6861 | 0.3699 | 0.0956 | `pipeline_oracle_type.json` |

## 表 2 · 换预训练基座（同超参，只换 --bert_path）

| 基座 | trigger F1 | argument F1 | event F1 | 来源 |
|---|---|---|---|---|
| bert-base-chinese | 0.8293 | 0.5633 | 0.1564 | `bert_linear_256_bert-base-chinese.json` |
| chinese-roberta-wwm-ext | 0.8230 | 0.5613 | 0.1727 | `bert_linear_256_chinese-roberta-wwm-ext.json` |
| chinese-macbert-base | 0.8122 | 0.5532 | 0.1535 | `bert_linear_256_chinese-macbert-base.json` |
| chinese-rbt3 | 0.7236 | 0.3615 | 0.0523 | `bert_linear_256_chinese-rbt3.json` |

## 表 3 · 生成式链路（n=200 子集；与下方判别式投影列同批样本才可比）

| 层次 | 方法 | trigger F1 | argument F1 | event F1 | 来源 |
|---|---|---|---|---|---|
| L3 生成式零样本（本地） | 本地 Qwen3-0.6B 零样本 | 0.4068 | 0.1167 | 0.0000 | `local_zero_n60.json` |
| L3 生成式零样本（外部大模型） | API 零样本 | 0.7789 | 0.5224 | 0.0402 | `api_zero_n200.json` |
| L3 生成式少样本 | API 少样本（few-shot） | 0.8321 | 0.5395 | 0.0852 | `api_few_n200.json` |
| L4 生成式微调 | Qwen3-0.6B + LoRA SFT | 0.9000 | 0.6971 | 0.1850 | `sft_lora_n200.json` |
| 判别式参照 | BERT+Linear（bert-base-chinese）@n200 | 0.8123 | 0.5598 | 0.1645 | `bert_linear_256_n200.json` |
| 判别式参照 | BERT+Linear（chinese-roberta-wwm-ext）@n200 | 0.8274 | 0.5534 | 0.1675 | `bert_linear_256_chinese-roberta-wwm-ext_n200.json` |
| 判别式参照 | BERT+Linear（chinese-macbert-base）@n200 | 0.8101 | 0.5545 | 0.1620 | `bert_linear_256_chinese-macbert-base_n200.json` |
| 判别式参照 | BERT+Linear（chinese-rbt3）@n200 | 0.7036 | 0.3521 | 0.0499 | `bert_linear_256_chinese-rbt3_n200.json` |

## 表 4 · 换任务：事件检测（句子级多标签，train 32,794 / dev 4,815）

| 基座 | micro-F1 | macro-F1 | 有无事件 F1 | 来源 |
|---|---|---|---|---|
| bert-base-chinese | 0.8027 | 0.7690 | 0.8244 | `detect_bert-base-chinese.json` |
| chinese-macbert-base | 0.8040 | 0.7710 | 0.8276 | `detect_chinese-macbert-base.json` |