r"""
SFT 效果评测（不修改主文件，只 import 它）

对 base / sft 两个 ckpt 各跑四件事：
  1. answer-only loss / PPL —— 只在"回答段"上算，base 和 sft 直接可比
  2. 停止符命中率          —— 生成 80 字内是否吐出 <|end|>
  3. 多样性 distinct-1/2   —— 所有回答拼起来后，1-gram / 2-gram 的不重复比例
                              （贪心解码下如果每个问题答得几乎一样，这两个值会很低 = 模式坍塌）
  4. 抽样问答              —— 前 N 条验证集问题的实际输出

用法（在 5\sft_lab 下）：
    python eval_sft.py --ckpts base.pt sft.pt --sft ../../sft_train/sft_val.jsonl --n_show 5
    python eval_sft.py --ckpts sft.pt --limit 60 --temperature 0.8 --topk 20   # 采样模式看多样性
"""

import argparse
import json
import math
import os

import torch
import torch.nn.functional as F

import transformer_lm_sft as M


def load(ckpt, device):
    ck = torch.load(ckpt, map_location=device)
    c = ck["args"]
    model = M.TransformerLM(len(ck["char2idx"]), c["d_model"], c["heads"], c["layers"],
                            c["seq_len"], 0.0,
                            use_pos=not c.get("no_pos", False),
                            causal=not c.get("no_mask", False)).to(device)
    model.load_state_dict(ck["model_state"])
    model.eval()
    return model, ck["char2idx"], ck["idx2char"], c


@torch.no_grad()
def answer_only_ppl(model, path, char2idx, seq_len, device, bs=32):
    ds = M.SFTDataset(path, char2idx, seq_len)
    total, n_tok = 0.0, 0
    for i in range(0, len(ds), bs):
        batch = [ds[j] for j in range(i, min(i + bs, len(ds)))]
        x, y = M.sft_collate(batch, char2idx[M.PAD_CHAR])
        x, y = x.to(device), y.to(device)
        logits = model(x)
        total += float(F.cross_entropy(logits.reshape(-1, logits.size(-1)),
                                       y.reshape(-1), reduction="sum", ignore_index=-100))
        n_tok += int((y != -100).sum())
    loss = total / max(1, n_tok)
    return loss, math.exp(loss)


@torch.no_grad()
def gen_once(model, char2idx, idx2char, question, c, max_new=80,
             temperature=0.0, topk=0, device="cpu"):
    prompt = f"{M.USER_TAG}{question}{M.ASST_TAG}"
    ids = [char2idx[ch] for ch in prompt]
    out = list(ids)
    stopped = False
    for _ in range(max_new):
        logits = model(torch.tensor([out[-c["seq_len"]:]], device=device))[0, -1]
        if temperature <= 0.01:
            nxt = int(logits.argmax())                       # 贪心，结果确定
        else:
            lg = logits / temperature
            if topk > 0:
                v, idx = torch.topk(lg, topk)
                nxt = int(idx[torch.multinomial(F.softmax(v, dim=-1), 1)])
            else:
                nxt = int(torch.multinomial(F.softmax(lg, dim=-1), 1))
        out.append(nxt)
        tail = "".join(idx2char.get(i, "") for i in out[len(ids):])
        if M.END_TAG in tail:
            stopped = True
            break
    ans = "".join(idx2char.get(i, "") for i in out[len(ids):]).replace(M.END_TAG, "")
    return ans.strip(), stopped


def distinct_n(texts, n):
    grams = []
    for t in texts:
        grams += [t[i:i + n] for i in range(len(t) - n + 1)]
    return len(set(grams)) / max(1, len(grams))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpts", nargs="+", default=["base.pt", "sft.pt"])
    ap.add_argument("--sft", default=None,
                    help="验证集 jsonl（不传则自动找 ../sft_train/ 或 ./data/）")
    ap.add_argument("--limit", type=int, default=0, help="只评前 N 条（0=全部）")
    ap.add_argument("--n_show", type=int, default=5)
    ap.add_argument("--max_new", type=int, default=80)
    ap.add_argument("--temperature", type=float, default=0.0, help="0=贪心（可复现）")
    ap.add_argument("--topk", type=int, default=0, help="采样时的 top-k，0=不截断")
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    sft_path = args.sft
    if not sft_path:
        for cand in (M.DEFAULT_SFT_VAL, os.path.join(M.HERE, "data", "sft_val.jsonl")):
            if os.path.exists(cand):
                sft_path = cand
                break
        if not sft_path:
            raise SystemExit("找不到验证集，请用 --sft 指定路径")
    rows = [json.loads(l) for l in open(sft_path, encoding="utf-8") if l.strip()]
    if args.limit:
        rows = rows[:args.limit]
    print(f"device: {device}  验证集 {sft_path}  评 {len(rows)} 条  "
          f"解码={'贪心' if args.temperature <= 0.01 else f'采样 T={args.temperature} topk={args.topk}'}\n")

    for path in args.ckpts:
        model, char2idx, idx2char, c = load(path, device)
        loss, ppl = answer_only_ppl(model, sft_path, char2idx, c["seq_len"], device)

        hit, ans_list, show = 0, [], []
        for r in rows:
            a, stopped = gen_once(model, char2idx, idx2char, r["instruction"], c,
                                  args.max_new, args.temperature, args.topk, device)
            hit += int(stopped)
            ans_list.append(a)
            if len(show) < args.n_show:
                show.append((r["instruction"], a))

        print("=" * 70)
        print(f"{path}")
        print(f"  answer-only loss = {loss:.4f}   PPL = {ppl:.2f}")
        print(f"  <|end|> 命中率   = {hit}/{len(rows)} = {hit/len(rows):.1%}"
              f"   平均长度 = {sum(len(a) for a in ans_list)/len(ans_list):.1f} 字")
        print(f"  多样性 distinct-1 = {distinct_n(ans_list, 1):.3f}  "
              f"distinct-2 = {distinct_n(ans_list, 2):.3f}   "
              f"完全不重复的回答数 = {len(set(ans_list))}/{len(ans_list)}")
        for q, a in show:
            print(f"  问: {q}")
            print(f"  答: {a}")
        print()


if __name__ == "__main__":
    main()
